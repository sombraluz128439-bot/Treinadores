package com.treinadores.flutuantes;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Bolha flutuante + janelinha com o HTML dos treinadores, por cima de outros apps. */
public class BubbleService extends Service {
    static final String STOP = "stop";
    static BubbleService inst;

    private static final String TITLE = "\uD83C\uDF93 Treinadores";

    private WindowManager wm;
    private SharedPreferences prefs;
    private TextView bubble;
    private TextView title;
    private LinearLayout panel;
    private WebView web;
    private WindowManager.LayoutParams bubbleLp;
    private WindowManager.LayoutParams panelLp;
    private boolean bubbleOn;
    private boolean panelOn;
    private boolean typing;
    private boolean dim;
    private int sizeIdx;
    private int savedY;
    private float dp;

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        dp = getResources().getDisplayMetrics().density;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences("bolha", MODE_PRIVATE);
        sizeIdx = prefs.getInt("size", 1);
        dim = prefs.getBoolean("dim", false);
        goForeground();
        buildBubble();
        buildPanel();
        collapse();
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        if (i != null && STOP.equals(i.getAction())) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        inst = null;
        try {
            if (panelOn) {
                wm.removeView(panel);
            }
        } catch (Exception e) {
            // ignora
        }
        try {
            if (bubbleOn) {
                wm.removeView(bubble);
            }
        } catch (Exception e) {
            // ignora
        }
        panelOn = false;
        bubbleOn = false;
        try {
            panel.removeAllViews();
            web.destroy();
        } catch (Exception e) {
            // ignora
        }
        TtsBridge.get(this).stop();
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        try {
            dp = getResources().getDisplayMetrics().density;
            applySize();
            if (panelOn) {
                wm.updateViewLayout(panel, panelLp);
            }
            if (bubbleOn) {
                clamp(bubbleLp);
                wm.updateViewLayout(bubble, bubbleLp);
            }
        } catch (Exception e) {
            // ignora
        }
    }

    // ---------- notificacao obrigatoria do servico ----------

    @SuppressWarnings("deprecation")
    private void goForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("bolha", "Bolha flutuante", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 1,
            new Intent(this, BubbleService.class).setAction(STOP),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent open = PendingIntent.getActivity(this, 0,
            new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "bolha")
            .setContentTitle("Treinadores flutuantes ligado")
            .setContentText("Arraste a bolha. Toque em Desligar para fechar.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Desligar", stop)
            .setOngoing(true)
            .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    // ---------- construcao das janelas ----------

    private int px(float v) {
        return (int) (v * dp + 0.5f);
    }

    private WindowManager.LayoutParams overlayLp(int w, int h, boolean focusable) {
        int f = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        if (!focusable) {
            f |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        }
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    private void buildBubble() {
        bubble = new TextView(this);
        bubble.setText("\uD83C\uDF93");
        bubble.setTextSize(26);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xE6171A2E);
        bg.setStroke(px(3), 0xFF00F0FF);
        bubble.setBackground(bg);
        bubbleLp = overlayLp(px(58), px(58), false);
        bubbleLp.x = prefs.getInt("bx", px(12));
        bubbleLp.y = prefs.getInt("by", px(200));
        drag(bubble, bubbleLp, bubble, "b", this::expand);
    }

    private void buildPanel() {
        web = new WebView(new ContextThemeWrapper(getApplicationContext(), android.R.style.Theme_Material_NoActionBar));
        Web.setup(this, web, null);
        web.loadUrl(Web.URL);

        title = new TextView(this);
        title.setText(TITLE);
        title.setTextColor(0xFF00F0FF);
        title.setTextSize(14);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(px(12), 0, 0, 0);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(0xFF171A2E);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        bar.addView(barBtn("\u2328", this::toggleTyping), btnLp());
        bar.addView(barBtn("\u25D0", this::toggleDim), btnLp());
        bar.addView(barBtn("\u2922", this::cycleSize), btnLp());
        bar.addView(barBtn("\u2014", this::collapse), btnLp());
        bar.addView(barBtn("\u2715", this::stopSelf), btnLp());

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(px(8));
        bg.setColor(0xFF0D0F1A);
        bg.setStroke(px(2), 0xFF00F0FF);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(bg);
        panel.setPadding(px(2), px(2), px(2), px(2));
        panel.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(40)));
        panel.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        panelLp = overlayLp(0, 0, false);
        panelLp.x = prefs.getInt("px", 0);
        panelLp.y = prefs.getInt("py", px(160));
        drag(title, panelLp, panel, "p", null);
    }

    private LinearLayout.LayoutParams btnLp() {
        return new LinearLayout.LayoutParams(px(44), ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private TextView barBtn(String t, final Runnable action) {
        TextView b = new TextView(this);
        b.setText(t);
        b.setTextSize(17);
        b.setTextColor(0xFFEEF0FF);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    // ---------- arrastar ----------

    @SuppressLint("ClickableViewAccessibility")
    private void drag(View handle, final WindowManager.LayoutParams lp, final View win,
                      final String key, final Runnable tap) {
        final float[] st = new float[4];
        final boolean[] moved = new boolean[1];
        handle.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    st[0] = e.getRawX();
                    st[1] = e.getRawY();
                    st[2] = lp.x;
                    st[3] = lp.y;
                    moved[0] = false;
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - st[0];
                    float dy = e.getRawY() - st[1];
                    if (!moved[0] && (Math.abs(dx) > px(8) || Math.abs(dy) > px(8))) {
                        moved[0] = true;
                    }
                    if (moved[0]) {
                        lp.x = (int) (st[2] + dx);
                        lp.y = (int) (st[3] + dy);
                        clamp(lp);
                        wm.updateViewLayout(win, lp);
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                    if (!moved[0]) {
                        if (tap != null) {
                            tap.run();
                        }
                    } else {
                        prefs.edit().putInt(key + "x", lp.x).putInt(key + "y", lp.y).apply();
                    }
                    break;
                default:
                    break;
            }
            return true;
        });
    }

    private int[] screen() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Rect b = wm.getCurrentWindowMetrics().getBounds();
                return new int[]{b.width(), b.height()};
            }
            DisplayMetrics m = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(m);
            return new int[]{m.widthPixels, m.heightPixels};
        } catch (Exception e) {
            DisplayMetrics m2 = getResources().getDisplayMetrics();
            return new int[]{m2.widthPixels, m2.heightPixels};
        }
    }

    private void clamp(WindowManager.LayoutParams lp) {
        int[] s = screen();
        lp.x = Math.max(0, Math.min(lp.x, s[0] - lp.width));
        lp.y = Math.max(0, Math.min(lp.y, s[1] - lp.height));
    }

    private void applySize() {
        int[] s = screen();
        boolean land = s[0] > s[1];
        float[][] p = land
            ? new float[][]{{0.34f, 0.62f}, {0.50f, 0.85f}, {0.74f, 1f}}
            : new float[][]{{0.72f, 0.26f}, {0.94f, 0.40f}, {1f, 0.68f}};
        float[] f = p[Math.max(0, Math.min(2, sizeIdx))];
        panelLp.width = (int) (s[0] * f[0]);
        panelLp.height = (int) (s[1] * f[1]);
        clamp(panelLp);
    }

    // ---------- acoes ----------

    void expand() {
        if (panelOn) {
            return;
        }
        if (bubbleOn) {
            wm.removeView(bubble);
            bubbleOn = false;
        }
        if (Web.dirty) {
            web.reload();
            Web.dirty = false;
        }
        applySize();
        panelLp.alpha = dim ? 0.7f : 1f;
        wm.addView(panel, panelLp);
        panelOn = true;
    }

    void collapse() {
        if (typing) {
            setTyping(false);
        }
        if (panelOn) {
            wm.removeView(panel);
            panelOn = false;
        }
        if (!bubbleOn) {
            clamp(bubbleLp);
            wm.addView(bubble, bubbleLp);
            bubbleOn = true;
        }
    }

    private void cycleSize() {
        sizeIdx = (sizeIdx + 1) % 3;
        prefs.edit().putInt("size", sizeIdx).apply();
        applySize();
        if (panelOn) {
            wm.updateViewLayout(panel, panelLp);
        }
    }

    private void toggleDim() {
        dim = !dim;
        prefs.edit().putBoolean("dim", dim).apply();
        panelLp.alpha = dim ? 0.7f : 1f;
        if (panelOn) {
            wm.updateViewLayout(panel, panelLp);
        }
    }

    private void toggleTyping() {
        setTyping(!typing);
    }

    // Janela normal nao rouba o foco do jogo. Para digitar, liga o foco (e sobe a janela).
    private void setTyping(boolean on) {
        if (on == typing) {
            return;
        }
        typing = on;
        if (on) {
            savedY = panelLp.y;
            panelLp.y = 0;
            panelLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
            title.setText("\u2328 digitando\u2026");
        } else {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(web.getWindowToken(), 0);
            panelLp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            panelLp.y = savedY;
            title.setText(TITLE);
        }
        if (panelOn) {
            wm.updateViewLayout(panel, panelLp);
        }
    }
}
