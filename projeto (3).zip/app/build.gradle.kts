plugins {
    id("com.android.application")
}

android {
    namespace = "com.treinadores.flutuantes"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.treinadores.flutuantes"
        minSdk = 29
        targetSdk = 34
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.0"
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        encoding = "UTF-8"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.8.0")
}
