package com.treinadores.flutuantes;
import org.junit.*;
import org.json.*;
import java.time.*;
import java.util.TimeZone;
import static org.junit.Assert.*;

public class ReminderScheduleTest {
    TimeZone original;
    @Before public void setup(){original=TimeZone.getDefault();TimeZone.setDefault(TimeZone.getTimeZone("America/Sao_Paulo"));}
    @After public void teardown(){TimeZone.setDefault(original);}
    long at(String s){return LocalDateTime.parse(s).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();}
    JSONObject item(String repeat,String time) throws Exception {return new JSONObject().put("repeat",repeat).put("time",time).put("date","2026-11-06").put("days",new JSONArray().put(1).put(5));}
    @Test public void dailyToday() throws Exception {assertEquals(at("2026-11-04T09:00"),ReminderStore.next(item("daily","09:00"),at("2026-11-04T08:00")));}
    @Test public void dailyTomorrow() throws Exception {assertEquals(at("2026-11-05T09:00"),ReminderStore.next(item("daily","09:00"),at("2026-11-04T10:00")));}
    @Test public void exactBoundarySchedulesNextDay() throws Exception {assertEquals(at("2026-11-05T09:00"),ReminderStore.next(item("daily","09:00"),at("2026-11-04T09:00")));}
    @Test public void weeklyNextSelectedDay() throws Exception {assertEquals(at("2026-11-06T09:00"),ReminderStore.next(item("weekly","09:00"),at("2026-11-04T08:00")));}
    @Test public void weeklyWrapsToMonday() throws Exception {assertEquals(at("2026-11-09T09:00"),ReminderStore.next(item("weekly","09:00"),at("2026-11-06T10:00")));}
    @Test public void onceUsesDate() throws Exception {assertEquals(at("2026-11-06T09:00"),ReminderStore.next(item("once","09:00"),at("2026-11-04T08:00")));}
    @Test public void onceInPastDoesNotRollForward() throws Exception {assertTrue(ReminderStore.next(item("once","09:00"),at("2026-11-07T08:00"))<at("2026-11-07T08:00"));}
    @Test public void daylightSavingGapMovesForward() throws Exception {TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));assertEquals(at("2027-03-14T03:30"),ReminderStore.next(item("daily","02:30"),at("2027-03-14T00:00")));}
    @Test public void daylightSavingKeepsLocalTimeNextDay() throws Exception {TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));assertEquals(at("2027-03-15T02:30"),ReminderStore.next(item("daily","02:30"),at("2027-03-14T04:00")));}
    @Test public void emptyWeekdaysHasNoOccurrence() throws Exception {JSONObject o=item("weekly","09:00").put("days",new JSONArray());assertEquals(-1,ReminderStore.next(o,at("2026-11-04T08:00")));}
}
