'use strict';
const mediaURL=m=>m&&/^[a-f0-9-]+\.(jpg|png|gif|webp|mp4|webm|mov|mp3|wav|ogg|m4a|bin)$/.test(m.file)?'https://appassets.androidplatform.net/media/'+m.file:'';
function richNode(tag,text,cls){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n}
/* ---- cor por letra (mesmas regras de LetterFx.java) ---- */
const FX_WS=/[\t\n\u000B\f\r\u001C-\u001F \u1680\u2000-\u2006\u2008-\u200A\u2028\u2029\u205F\u3000]/;
function fxInt(h){return /^#[0-9a-f]{6}$/i.test(h||'')?parseInt(h.slice(1),16):null}
function fxHex(n){return '#'+(n&0xffffff).toString(16).padStart(6,'0')}
function fxLerp(a,b,t){const ch=s=>Math.round(((a>>s)&255)+(((b>>s)&255)-((a>>s)&255))*t);return (ch(16)<<16)|(ch(8)<<8)|ch(0)}
function fxHsv(h){const s=.85,v=1;h=((h%360)+360)%360;const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c;let r,g,b;
 if(h<60){r=c;g=x;b=0}else if(h<120){r=x;g=c;b=0}else if(h<180){r=0;g=c;b=x}else if(h<240){r=0;g=x;b=c}else if(h<300){r=x;g=0;b=c}else{r=c;g=0;b=x}
 return (Math.round((r+m)*255)<<16)|(Math.round((g+m)*255)<<8)|Math.round((b+m)*255)}
/* cor (#rrggbb) de cada letra do texto; base = cor normal do campo */
function fxColors(text,fx,base){
 const cps=Array.from(text||''),out=new Array(cps.length),mode=fx&&fx.mode||'solid';
 const c1=fxInt(fx&&fx.c1),c2=fxInt(fx&&fx.c2),b=fxInt(base),custom=(fx&&fx.custom)||[];
 const A=c1===null?0x2f7bff:c1,B=c2===null?0xffd93b:c2,BASE=b===null?0xffffff:b;
 let total=0;cps.forEach(c=>{if(!FX_WS.test(c))total++});
 let k=0,word=-1,inWord=false;
 for(let i=0;i<cps.length;i++){const space=FX_WS.test(cps[i]);const cu=fxInt(custom[i]);let c=BASE;
  if(space){inWord=false}
  else{if(!inWord){word++;inWord=true}
   if(mode==='alt')c=k%2===0?A:B;else if(mode==='words')c=word%2===0?A:B;
   else if(mode==='grad')c=fxLerp(A,B,total<=1?0:k/(total-1));
   else if(mode==='rainbow')c=fxHsv(360*k/Math.max(total,1));
   k++}
  if(mode==='custom'&&cu!==null)c=cu;
  out[i]=fxHex(c)}
 return out}
/* escreve o texto no elemento, uma <span> por trecho de mesma cor (sem efeito: texto simples) */
function fxFill(node,text,fx,base){
 node.replaceChildren();text=text||'';
 if(!fx||!fx.mode||fx.mode==='solid'){node.textContent=text;return}
 const cps=Array.from(text),cols=fxColors(text,fx,base);let i=0;
 while(i<cps.length){let j=i;while(j<cps.length&&cols[j]===cols[i])j++;const sp=document.createElement('span');sp.textContent=cps.slice(i,j).join('');sp.style.color=cols[i];node.append(sp);i=j}}
if(typeof module!=='undefined')module.exports={fxColors};
function renderRichCard(root,o){
 root.querySelectorAll('audio,video').forEach(m=>m.pause());root.replaceChildren();root.className='rich-card';
 const bounded=(v,d,min,max)=>Math.max(min,Math.min(max,Number.isFinite(Number(v))?Number(v):d));
 Object.assign(root.style,{backgroundColor:o.bg||'#182139',color:o.textColor||'#ffffff',borderRadius:bounded(o.radius,20,0,64)+'px',padding:bounded(o.padding,20,0,48)+'px',border:Math.max(0,Number(o.borderWidth)||0)+'px solid '+(o.accent||'#31d7c3'),borderLeft:Math.max(4,Number(o.borderWidth)||0)+'px solid '+(o.accent||'#31d7c3'),textAlign:o.align||'left',fontFamily:['serif','monospace'].includes(o.font)?o.font:'system-ui',backgroundImage:o.background&&mediaURL(o.background)?'linear-gradient(#000a,#000a),url("'+mediaURL(o.background)+'")':'none',backgroundSize:'cover',backgroundPosition:'center'});
 const head=richNode('header',undefined,'rich-head');head.style.justifyContent=o.align==='center'?'center':o.align==='right'?'flex-end':'flex-start';
 if(o.avatar&&mediaURL(o.avatar)){const img=richNode('img');img.src=mediaURL(o.avatar);img.alt='Foto de '+(o.trainer||'treinador');img.className='rich-avatar';img.style.width=img.style.height=bounded(o.avatarSize,72,32,180)+'px';head.append(img)}
 const identity=richNode('div');const trainer=richNode('strong');trainer.style.color=o.accent||'#31d7c3';trainer.append(document.createTextNode((o.emoji||'')+' '));const trainerName=richNode('span');fxFill(trainerName,o.trainer||'Nome do treinador',o.fxTrainer,o.accent||'#31d7c3');trainer.append(trainerName);identity.append(trainer);
 if(o.showTime!==false){const sub=richNode('small',o.time?'Lembrete • '+o.time:'Mensagem do treinador');sub.style.display='block';identity.append(sub)}head.append(identity);root.append(head);
 const title=richNode('h2');fxFill(title,o.title||'',o.fxTitle,o.titleColor||'#ffffff');title.style.color=o.titleColor||'#fff';title.style.fontSize=bounded(o.titleSize,22,8,72)+'px';root.append(title);
 if(o.message){const message=richNode('div',undefined,'rich-message');fxFill(message,o.message,o.fxMessage,o.textColor||'#ffffff');Object.assign(message.style,{fontSize:bounded(o.size,16,8,72)+'px',fontWeight:o.bold?'bold':'normal',fontStyle:o.italic?'italic':'normal',lineHeight:bounded(o.lineHeight,1.5,1,3)});root.append(message)}
 (o.media||[]).forEach((m,i)=>{
  const url=mediaURL(m);if(!url)return;const figure=richNode('figure');let el;
  if(m.mime.startsWith('image/')){el=richNode('img');el.alt=m.caption||m.name||'Imagem do treinador';el.loading='lazy'}
  else if(m.mime.startsWith('video/')){el=richNode('video');el.controls=true;el.playsInline=true;el.preload='metadata';el.loop=!!o.loop;el.muted=!!o.muted;el.setAttribute('playsinline','')}
  else if(m.mime.startsWith('audio/')){el=richNode('audio');el.controls=true;el.preload='metadata';el.loop=!!o.loop;el.muted=!!o.muted;figure.append(richNode('div','🎵 '+(m.name||'Áudio')))}
  else return;
  el.src=url;el.style.objectFit=o.fit||'contain';if(el.tagName!=='AUDIO')el.style.maxHeight=bounded(o.mediaHeight,300,80,900)+'px';el.addEventListener('error',()=>{if(!figure.querySelector('.media-error'))figure.append(richNode('p','Não foi possível reproduzir esta mídia. Verifique o arquivo e o formato compatível com seu aparelho.','media-error'))});figure.append(el);
  if(m.caption)figure.append(richNode('figcaption',m.caption));root.append(figure);
 });
 if(o.actionUrl&&/^https:\/\//i.test(o.actionUrl)){const b=richNode('button',o.actionLabel||'Abrir link');b.type='button';b.onclick=()=>ReminderAPI.openLink(o.actionUrl);root.append(b)}
}
