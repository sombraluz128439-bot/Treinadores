package com.treinadores.flutuantes;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.Build;
import android.provider.Settings;
import android.widget.RemoteViews;
import org.json.*;
import java.time.*;

/** Lembretes nativos: independem da bolha, do WebView e dos timers JavaScript. */
public final class ReminderStore {
    private ReminderStore() {}
    static android.content.SharedPreferences prefs(Context c) { return c.getSharedPreferences("lembretes_v1", 0); }
    public static synchronized JSONArray all(Context c) {
        try { return new JSONArray(prefs(c).getString("items", "[]")); } catch(Exception e) { return new JSONArray(); }
    }
    static void persist(Context c, JSONArray a) {
        if(!prefs(c).edit().putString("items", a.toString()).commit()) throw new IllegalStateException("Não foi possível salvar no aparelho.");
    }
    public static boolean exact(Context c) { return Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager.class).canScheduleExactAlarms(); }
    public static boolean allowed(Context c) { return c.getSystemService(NotificationManager.class).areNotificationsEnabled(); }
    static String text(JSONObject o, String k, String def, int max) { String s=o.optString(k,def); return s.substring(0,Math.min(s.length(),max)); }
    static int color(JSONObject o,String k,String def) { try { return Color.parseColor(o.optString(k,def)) | 0xff000000; } catch(Exception e){return Color.parseColor(def);} }
    static JSONObject clean(JSONObject in) throws Exception {
        JSONObject o=new JSONObject();
        o.put("id", in.optInt("id",0));
        o.put("trainer",text(in,"trainer","Treinador",100).trim());
        o.put("title",text(in,"title","Hora de treinar!",150));
        o.put("message",text(in,"message","",4000));
        o.put("emoji",text(in,"emoji","💪",16));
        if(o.getString("trainer").isEmpty() || o.getString("message").trim().isEmpty()) throw new IllegalArgumentException("Preencha o treinador e a mensagem.");
        String time=in.optString("time","08:00"); LocalTime.parse(time); o.put("time",time);
        String repeat=in.optString("repeat","once");
        if(!repeat.equals("once") && !repeat.equals("daily") && !repeat.equals("weekly")) throw new IllegalArgumentException("Repetição inválida.");
        o.put("repeat",repeat);
        String date=in.optString("date",LocalDate.now().toString()); LocalDate.parse(date); o.put("date",date);
        JSONArray days=new JSONArray(); for(int d=1;d<=7;d++){JSONArray src=in.optJSONArray("days");if(src!=null)for(int j=0;j<src.length();j++)if(src.optInt(j)==d){days.put(d);break;}}
        if(repeat.equals("weekly") && days.length()==0) throw new IllegalArgumentException("Escolha pelo menos um dia da semana.");
        o.put("days",days);
        for(String k:new String[]{"accent","bg","titleColor","textColor"}) {String def=k.equals("bg")?"#182139":k.equals("accent")?"#31D7C3":"#FFFFFF";o.put(k,String.format("#%06X",color(in,k,def)&0xffffff));}
        o.put("size",Math.max(12,Math.min(24,in.optInt("size",16))));
        for(String k:new String[]{"sound","vibrate","bold","enabled"}) o.put(k,in.optBoolean(k,k.equals("enabled")||k.equals("sound")||k.equals("vibrate")));
        o.put("italic",in.optBoolean("italic",false));
        o.put("align",in.optString("align","left").equals("center")?"center":"left");
        String privacy=in.optString("privacy","private");o.put("privacy",privacy.equals("public")||privacy.equals("secret")?privacy:"private");
        o.put("lastDelivery",in.optLong("lastDelivery",0));
        return o;
    }
    public static long next(JSONObject o,long now) {
        ZoneId zone=ZoneId.systemDefault(); LocalTime t=LocalTime.parse(o.optString("time","08:00"));
        if(o.optString("repeat").equals("once")) return LocalDate.parse(o.optString("date")).atTime(t).atZone(zone).toInstant().toEpochMilli();
        LocalDate today=Instant.ofEpochMilli(now).atZone(zone).toLocalDate();
        for(int i=0;i<9;i++) {LocalDate day=today.plusDays(i);boolean ok=o.optString("repeat").equals("daily");JSONArray ds=o.optJSONArray("days");
            if(ds!=null)for(int j=0;j<ds.length();j++)if(ds.optInt(j)==day.getDayOfWeek().getValue())ok=true;
            long at=day.atTime(t).atZone(zone).toInstant().toEpochMilli();if(ok&&at>now)return at;
        } return -1;
    }
    static PendingIntent pending(Context c,int id) {return PendingIntent.getBroadcast(c,id,new Intent(c,ReminderReceiver.class).setAction("com.treinadores.REMINDER").putExtra("id",id),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static void cancel(Context c,int id) {c.getSystemService(AlarmManager.class).cancel(pending(c,id));}
    static void schedule(Context c,JSONObject o) {
        int id=o.optInt("id");cancel(c,id);if(!o.optBoolean("enabled",true))return;
        long at=next(o,System.currentTimeMillis()); if(at<=System.currentTimeMillis())return;
        AlarmManager a=c.getSystemService(AlarmManager.class);PendingIntent p=pending(c,id);
        if(exact(c)){try{a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);return;}catch(SecurityException ignored){}}
        a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);
    }
    public static synchronized JSONObject save(Context c,JSONObject raw) throws Exception {
        JSONObject o=clean(raw);JSONArray a=all(c);int id=o.optInt("id"), idx=-1;
        for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optInt("id")==id)idx=i;
        if(idx<0){if(a.length()>=200)throw new IllegalArgumentException("Limite de 200 lembretes. Exclua um para continuar.");id=Math.max(1,prefs(c).getInt("sequence",0)+1);if(!prefs(c).edit().putInt("sequence",id).commit())throw new IllegalStateException("Erro ao gerar identificador.");o.put("id",id);}
        if(o.optBoolean("enabled") && o.optString("repeat").equals("once") && next(o,System.currentTimeMillis())<=System.currentTimeMillis())throw new IllegalArgumentException("Escolha uma data e hora futuras.");
        if(idx<0)a.put(o);else a.put(idx,o);persist(c,a);schedule(c,o);return o;
    }
    public static synchronized void remove(Context c,int id) throws Exception {
        JSONArray a=all(c), out=new JSONArray();for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optInt("id")!=id)out.put(a.get(i));persist(c,out);cancel(c,id);c.getSystemService(NotificationManager.class).cancel("trainer",id);
    }
    public static synchronized void reschedule(Context c) {
        JSONArray a=all(c);boolean changed=false;long now=System.currentTimeMillis();
        for(int i=0;i<a.length();i++)try{JSONObject o=a.getJSONObject(i);if(o.optBoolean("enabled")&&o.optString("repeat").equals("once")&&next(o,now)<=now){o.put("enabled",false);o.put("missed",true);changed=true;}schedule(c,o);}catch(Exception ignored){}
        if(changed)persist(c,a);
    }
    public static synchronized void fire(Context c,int id) throws Exception {
        JSONArray a=all(c);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(o.optInt("id")!=id||!o.optBoolean("enabled"))continue;
            long now=System.currentTimeMillis();if(now-o.optLong("lastDelivery",0)<1000)return;
            o.put("lastDelivery",now);if(o.optString("repeat").equals("once"))o.put("enabled",false);
            persist(c,a);post(c,o,id);schedule(c,o);return;
        }
    }
    public static String channel(JSONObject o) {return "coach_v1_"+(o.optBoolean("sound")?"s":"q")+(o.optBoolean("vibrate")?"v":"n");}
    static void ensureChannel(Context c,JSONObject o) {
        NotificationManager m=c.getSystemService(NotificationManager.class);String id=channel(o);if(m.getNotificationChannel(id)!=null)return;
        NotificationChannel ch=new NotificationChannel(id,"Treinadores • "+(o.optBoolean("sound")?"com som":"sem som")+" • "+(o.optBoolean("vibrate")?"vibrar":"sem vibração"),NotificationManager.IMPORTANCE_HIGH);
        if(!o.optBoolean("sound"))ch.setSound(null,null);ch.enableVibration(o.optBoolean("vibrate"));if(o.optBoolean("vibrate"))ch.setVibrationPattern(new long[]{0,200,120,200});m.createNotificationChannel(ch);
    }
    static RemoteViews view(Context c,JSONObject o,boolean big) {
        RemoteViews r=new RemoteViews(c.getPackageName(),big?R.layout.reminder_big:R.layout.reminder_small);
        r.setInt(R.id.reminder_card,"setBackgroundColor",color(o,"bg","#182139"));
        r.setInt(R.id.reminder_stripe,"setBackgroundColor",color(o,"accent","#31D7C3"));
        r.setTextViewText(R.id.reminder_trainer,o.optString("emoji")+" "+o.optString("trainer"));r.setTextColor(R.id.reminder_trainer,color(o,"accent","#31D7C3"));
        r.setTextViewText(R.id.reminder_title,o.optString("title"));r.setTextColor(R.id.reminder_title,color(o,"titleColor","#FFFFFF"));
        CharSequence msg=o.optString("message");android.text.SpannableString span=new android.text.SpannableString(msg);
        int style=(o.optBoolean("bold")?1:0)|(o.optBoolean("italic")?2:0);span.setSpan(new android.text.style.StyleSpan(style),0,span.length(),0);
        r.setTextViewText(R.id.reminder_message,span);r.setTextColor(R.id.reminder_message,color(o,"textColor","#FFFFFF"));r.setTextViewTextSize(R.id.reminder_message,android.util.TypedValue.COMPLEX_UNIT_SP,o.optInt("size",16));
        int gravity=o.optString("align").equals("center")?android.view.Gravity.CENTER:android.view.Gravity.START;
        for(int id:new int[]{R.id.reminder_trainer,R.id.reminder_title,R.id.reminder_message})r.setInt(id,"setGravity",gravity);
        return r;
    }
    public static JSONObject status(Context c) throws Exception { JSONObject o=new JSONObject().put("notifications",allowed(c)).put("exact",exact(c));JSONObject channels=new JSONObject();NotificationManager m=c.getSystemService(NotificationManager.class);for(String id:new String[]{"coach_v1_sv","coach_v1_sn","coach_v1_qv","coach_v1_qn"}){NotificationChannel ch=m.getNotificationChannel(id);channels.put(id,ch==null||ch.getImportance()!=NotificationManager.IMPORTANCE_NONE);}return o.put("channels",channels);}
    public static void post(Context c,JSONObject o,int id) {
        if(!allowed(c))return;ensureChannel(c,o);
        PendingIntent open=PendingIntent.getActivity(c,0,new Intent(c,EditorActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        int privacy=o.optString("privacy").equals("public")?Notification.VISIBILITY_PUBLIC:o.optString("privacy").equals("secret")?Notification.VISIBILITY_SECRET:Notification.VISIBILITY_PRIVATE;
        Notification publicVersion=new Notification.Builder(c,channel(o)).setSmallIcon(R.drawable.ic_reminder).setContentTitle("Treinadores").setContentText("Você tem um lembrete de treino.").build();
        Notification n=new Notification.Builder(c,channel(o)).setSmallIcon(R.drawable.ic_reminder).setColor(color(o,"accent","#31D7C3")).setContentTitle(o.optString("trainer")+" • "+o.optString("title")).setContentText(o.optString("message")).setCustomContentView(view(c,o,false)).setCustomBigContentView(view(c,o,true)).setStyle(new Notification.DecoratedCustomViewStyle()).setContentIntent(open).setAutoCancel(true).setVisibility(privacy).setPublicVersion(publicVersion).setCategory(Notification.CATEGORY_REMINDER).build();
        c.getSystemService(NotificationManager.class).notify("trainer",id,n);
    }
    public static void test(Context c,JSONObject in) throws Exception {
        if(!allowed(c))throw new IllegalStateException("Ative a permissão de notificações primeiro.");JSONObject o=clean(in);ensureChannel(c,o);NotificationChannel ch=c.getSystemService(NotificationManager.class).getNotificationChannel(channel(o));if(ch.getImportance()==NotificationManager.IMPORTANCE_NONE)throw new IllegalStateException("Este canal está bloqueado. Abra os canais do Android.");post(c,o,0);
    }
}
