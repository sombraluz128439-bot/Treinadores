package com.treinadores.flutuantes;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Tela inicial: permissao, ligar/desligar a bolha e abrir em tela cheia. */
public class MainActivity extends Activity {
    private TextView status;
    private Button ttsBtn;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("bolha", MODE_PRIVATE);
        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (20 * d);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, (int) (36 * d), pad, pad);

        col.addView(text("\uD83C\uDF93 Treinadores Flutuantes", 24, 0xFF00F0FF));
        col.addView(text("Siga na ordem. Com a bolha ligada, abra seu jogo: ela fica por cima. "
            + "Toque na bolha para abrir os treinadores e arraste para mover.", 15, 0xFFEEF0FF));
        status = text("", 15, 0xFFAABBFF);
        col.addView(status);

        col.addView(button("1) Permitir \"Sobrepor a outros apps\"", () ->
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())))));
        col.addView(button("2) Ligar a bolha", this::ligar));
        col.addView(button("3) Abrir treinadores em tela cheia (importar backup / editar)", () ->
            startActivity(new Intent(this, EditorActivity.class))));
        col.addView(button("\uD83C\uDFA8 Cores da janela flutuante", () ->
            startActivity(new Intent(this, EditorActivity.class).putExtra("cores", true))));
        col.addView(button("Desligar a bolha", () ->
            stopService(new Intent(this, BubbleService.class))));
        ttsBtn = button("", this::toggleTts);
        col.addView(ttsBtn);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0D0F1A);
        sv.addView(col);
        setContentView(sv);

        if (Build.VERSION.SDK_INT >= 33
            && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        status.setText("Permissão de sobrepor: "
            + (Settings.canDrawOverlays(this) ? "\u2705 ok" : "\u274C falta (passo 1)"));
        ttsBtn.setText("Voz: "
            + (prefs.getBoolean("tts", true) ? "Android TTS (padrão)" : "do WebView")
            + "  \u2014  toque para trocar");
    }

    private TextView text(String t, float size, int color) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(0, 0, 0, (int) (14 * getResources().getDisplayMetrics().density));
        return v;
    }

    private Button button(String t, final Runnable action) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setOnClickListener(v -> action.run());
        return bt;
    }

    private void ligar() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Faltou o passo 1: permitir sobrepor a outros apps.", Toast.LENGTH_LONG).show();
            return;
        }
        startForegroundService(new Intent(this, BubbleService.class));
        Toast.makeText(this, "Bolha ligada! Abra seu jogo.", Toast.LENGTH_LONG).show();
    }

    private void toggleTts() {
        boolean novo = !prefs.getBoolean("tts", true);
        prefs.edit().putBoolean("tts", novo).apply();
        Toast.makeText(this, "Desligue e ligue a bolha (e reabra a tela cheia) para aplicar.", Toast.LENGTH_LONG).show();
        onResume();
    }
}
