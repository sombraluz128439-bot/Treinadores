package com.treinadores.flutuantes;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.provider.MediaStore;
import android.webkit.*;
import android.speech.tts.TextToSpeech;
import androidx.webkit.WebViewAssetLoader;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class RemindersActivity extends Activity {
    private WebView web;
    private String target="media";
    private android.view.View fullVideo;private WebChromeClient.CustomViewCallback fullCallback;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private TextToSpeech tts;private boolean speechReady=false;private String pendingSpeech;
    private static final String ORIGIN="https://appassets.androidplatform.net";
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);if(state!=null)target=state.getString("mediaTarget","media");
        web=new WebView(this);setContentView(web);
        web.setBackgroundColor(0xff0d1321);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onJsConfirm(WebView view,String url,String message,JsResult result){new android.app.AlertDialog.Builder(RemindersActivity.this).setMessage(message).setPositiveButton("Confirmar",(d,w)->result.confirm()).setNegativeButton("Cancelar",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;}
            @Override public void onShowCustomView(android.view.View view,CustomViewCallback callback){if(fullVideo!=null){callback.onCustomViewHidden();return;}fullVideo=view;fullCallback=callback;web.setVisibility(android.view.View.GONE);addContentView(view,new android.view.ViewGroup.LayoutParams(-1,-1));}
            @Override public void onHideCustomView(){hideFullVideo();}
        });
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){if("appassets.androidplatform.net".equals(r.getUrl().getHost())&&r.getUrl().getPath()!=null&&r.getUrl().getPath().startsWith("/media/"))return ReminderMedia.response(RemindersActivity.this,r);return loader.shouldInterceptRequest(r.getUrl());}
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;}
        });
        web.addJavascriptInterface(new Bridge(),"ReminderAPI");
        web.loadUrl(ORIGIN+"/assets/"+(getIntent().hasExtra("detailId")?"reminder_view.html":"reminders.html"));
        tts=new TextToSpeech(this,status->{speechReady=status==TextToSpeech.SUCCESS;if(speechReady&&tts!=null){tts.setLanguage(new Locale("pt","BR"));if(pendingSpeech!=null)speakText(pendingSpeech);}});
    }
    private void hideFullVideo(){if(fullVideo!=null){((android.view.ViewGroup)fullVideo.getParent()).removeView(fullVideo);fullVideo=null;if(web!=null)web.setVisibility(android.view.View.VISIBLE);if(fullCallback!=null){fullCallback.onCustomViewHidden();fullCallback=null;}}}
    @Override public void onBackPressed(){if(fullVideo!=null)hideFullVideo();else super.onBackPressed();}
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putString("mediaTarget",target);}
    @Override public void onResume(){super.onResume();ReminderStore.reschedule(this);if(web!=null){web.onResume();web.evaluateJavascript("window.refresh&&refresh()",null);}}
    @Override public void onPause(){if(web!=null){web.evaluateJavascript("document.querySelectorAll('video,audio').forEach(function(m){m.pause()})",null);web.onPause();}if(tts!=null)tts.stop();super.onPause();}
    @Override public void onDestroy(){hideFullVideo();worker.shutdown();if(tts!=null){tts.stop();tts.shutdown();}if(web!=null){web.removeJavascriptInterface("ReminderAPI");web.destroy();web=null;}super.onDestroy();}
    private interface Call { Object get() throws Exception; }
    private String reply(Call call) {try{return new JSONObject().put("ok",true).put("data",call.get()).toString();}catch(Exception e){try{return new JSONObject().put("ok",false).put("error",e.getMessage()==null?"Operação não concluída.":e.getMessage()).toString();}catch(Exception ignore){return "{\"ok\":false,\"error\":\"Erro interno\"}";}}}
    private void notice(String message){runOnUiThread(()->{if(web!=null)web.evaluateJavascript("window.toast&&toast("+JSONObject.quote(message)+")",null);});}
    private void speakText(String text){
        pendingSpeech=text;if(!speechReady){notice("Aguarde o serviço de voz. Verifique se há uma voz em português instalada.");return;}
        tts.stop();int limit=TextToSpeech.getMaxSpeechInputLength();for(int i=0;i<text.length();i+=limit)tts.speak(text.substring(i,Math.min(text.length(),i+limit)),i==0?TextToSpeech.QUEUE_FLUSH:TextToSpeech.QUEUE_ADD,null,"lembrete-"+i);pendingSpeech=null;
    }
    public class Bridge {
        @JavascriptInterface public String list(){return reply(()->ReminderStore.all(RemindersActivity.this));}
        @JavascriptInterface public String detail(){return reply(()->{String raw=ReminderStore.prefs(RemindersActivity.this).getString("display_"+getIntent().getIntExtra("detailId",0),null);if(raw==null)throw new IllegalStateException("Lembrete indisponível.");return new JSONObject(raw);});}
        @JavascriptInterface public String status(){return reply(()->ReminderStore.status(RemindersActivity.this));}
        @JavascriptInterface public String save(String json){return reply(()->ReminderStore.save(RemindersActivity.this,new JSONObject(json)));}
        @JavascriptInterface public String remove(int id){return reply(()->{ReminderStore.remove(RemindersActivity.this,id);return true;});}
        @JavascriptInterface public String test(String json){return reply(()->{ReminderStore.test(RemindersActivity.this,new JSONObject(json));return true;});}
        @JavascriptInterface public void preview(String json){worker.execute(()->{try{JSONObject o=ReminderStore.clean(new JSONObject(json));int id=-1;if(!ReminderStore.prefs(RemindersActivity.this).edit().putString("display_"+id,o.toString()).commit())throw new IOException("Erro ao preparar prévia.");runOnUiThread(()->startActivity(new Intent(RemindersActivity.this,RemindersActivity.class).putExtra("detailId",id)));}catch(Exception e){notice(e.getMessage());}});}
        @JavascriptInterface public void speak(String text){runOnUiThread(()->speakText(text));}
        @JavascriptInterface public void stopSpeech(){runOnUiThread(()->{pendingSpeech=null;if(tts!=null)tts.stop();});}
        @JavascriptInterface public void openLink(String url){runOnUiThread(()->{try{Uri u=Uri.parse(url);if(!"https".equalsIgnoreCase(u.getScheme())||u.getHost()==null)throw new IllegalArgumentException();startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){notice("Informe um link HTTPS válido ou instale um navegador.");}});}
        @JavascriptInterface public void pick(String kind){runOnUiThread(()->{
            target=kind.equals("avatar")?"avatar":kind.equals("background")?"background":"media";
            try {Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(target.equals("media")?"*/*":"image/*");if(target.equals("media")){i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*","audio/*"});i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);}startActivityForResult(i,101);}catch(Exception e){notice("O seletor de arquivos não está disponível neste aparelho.");}
        });}
        @JavascriptInterface public void capture(String kind){runOnUiThread(()->{target="media";try{startActivityForResult(new Intent(kind.equals("audio")?MediaStore.Audio.Media.RECORD_SOUND_ACTION:MediaStore.ACTION_VIDEO_CAPTURE),102);}catch(Exception e){notice("Instale um aplicativo de câmera/gravador ou use Adicionar arquivos.");}});}
        @JavascriptInterface public void permissions(String type){runOnUiThread(()->{
            try{
                if(type.equals("notifications")&&Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},91);return;}
                Intent i;
                if(type.equals("exact")&&Build.VERSION.SDK_INT>=31)i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName()));
                else i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());
                startActivity(i);
            }catch(Exception e){notice("Abra as permissões do app nas configurações do Android.");}
        });}
        /** Abre as configurações do canal só deste lembrete: dá para escolher outro toque para ele. */
        @JavascriptInterface public void channelSettings(int id){runOnUiThread(()->{try{
            JSONObject target=null;JSONArray a=ReminderStore.all(RemindersActivity.this);for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optInt("id")==id)target=a.getJSONObject(i);
            if(target==null||!target.optBoolean("ownChannel"))throw new IllegalStateException("Ative \"Canal próprio\" e salve este lembrete primeiro.");
            ReminderStore.ensureChannel(RemindersActivity.this,target);
            startActivity(new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()).putExtra(Settings.EXTRA_CHANNEL_ID,ReminderStore.channel(target)));
        }catch(Exception e){notice(e.getMessage()==null?"Não consegui abrir as configurações do canal.":e.getMessage());}});}
        @JavascriptInterface public void close(){runOnUiThread(()->finish());}
    }
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if((req!=101&&req!=102)||result!=RESULT_OK||data==null)return;
        ArrayList<Uri> uris=new ArrayList<>();if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)uris.add(data.getClipData().getItemAt(i).getUri());}else if(data.getData()!=null)uris.add(data.getData());
        final String dest=target;notice("Importando mídias para o armazenamento privado do app…");
        worker.execute(()->{JSONArray out=new JSONArray();ArrayList<String> errors=new ArrayList<>();for(Uri uri:uris){try{out.put(ReminderMedia.importUri(this,uri,!dest.equals("media")));}catch(Exception e){errors.add(e.getMessage());}}
            runOnUiThread(()->{if(web==null)return;web.evaluateJavascript("window.mediaImported&&mediaImported("+JSONObject.quote(dest)+","+out+")",null);if(!errors.isEmpty())notice(String.join("; ",errors));});});
    }
    @Override public void onRequestPermissionsResult(int req,String[] permissions,int[] results){super.onRequestPermissionsResult(req,permissions,results);if(web!=null)web.evaluateJavascript("window.refresh&&refresh()",null);}
}
