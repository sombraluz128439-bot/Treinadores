package com.treinadores.flutuantes;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import androidx.webkit.WebViewAssetLoader;
import org.json.*;

public class RemindersActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);web=new WebView(this);setContentView(web);
        web.setBackgroundColor(0xff0d1321);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){return loader.shouldInterceptRequest(r.getUrl());}
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !r.getUrl().toString().equals("https://appassets.androidplatform.net/assets/reminders.html");}
        });
        web.addJavascriptInterface(new Bridge(),"ReminderAPI");
        web.loadUrl("https://appassets.androidplatform.net/assets/reminders.html");
    }
    @Override public void onResume(){super.onResume();ReminderStore.reschedule(this);if(web!=null)web.evaluateJavascript("window.refresh&&refresh()",null);}
    @Override public void onDestroy(){if(web!=null){web.removeJavascriptInterface("ReminderAPI");web.destroy();}super.onDestroy();}
    private interface Call { Object get() throws Exception; }
    private String reply(Call call) {try{return new JSONObject().put("ok",true).put("data",call.get()).toString();}catch(Exception e){try{return new JSONObject().put("ok",false).put("error",e.getMessage()==null?"Operação não concluída.":e.getMessage()).toString();}catch(Exception ignore){return "{\"ok\":false,\"error\":\"Erro interno\"}";}}}
    public class Bridge {
        @JavascriptInterface public String list(){return reply(()->ReminderStore.all(RemindersActivity.this));}
        @JavascriptInterface public String status(){return reply(()->ReminderStore.status(RemindersActivity.this));}
        @JavascriptInterface public String save(String json){return reply(()->ReminderStore.save(RemindersActivity.this,new JSONObject(json)));}
        @JavascriptInterface public String remove(int id){return reply(()->{ReminderStore.remove(RemindersActivity.this,id);return true;});}
        @JavascriptInterface public String test(String json){return reply(()->{ReminderStore.test(RemindersActivity.this,new JSONObject(json));return true;});}
        @JavascriptInterface public void permissions(String type){runOnUiThread(()->{
            try{
                if(type.equals("notifications")&&Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},91);return;}
                Intent i;
                if(type.equals("exact")&&Build.VERSION.SDK_INT>=31)i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName()));
                else i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());
                startActivity(i);
            }catch(Exception e){android.widget.Toast.makeText(RemindersActivity.this,"Abra as permissões do app nas configurações do Android.",android.widget.Toast.LENGTH_LONG).show();}
        });}
        @JavascriptInterface public void close(){runOnUiThread(()->finish());}
    }
    @Override public void onRequestPermissionsResult(int req,String[] permissions,int[] results){super.onRequestPermissionsResult(req,permissions,results);if(web!=null)web.evaluateJavascript("window.refresh&&refresh()",null);}
}
