package com.treinadores.flutuantes;

/**
 * Cor por letra. Java puro (sem Android) para poder ser testado no computador.
 * O JavaScript em reminder-rich.js (fxColors) segue exatamente as mesmas regras:
 *
 *  solid   : todas as letras na cor normal
 *  alt     : alterna c1 / c2 letra a letra (espaços não contam)
 *  grad    : degradê de c1 até c2 ao longo das letras
 *  rainbow : arco-íris ao longo das letras
 *  words   : alterna c1 / c2 palavra a palavra
 *  custom  : cada letra tem a sua cor (índice conta todos os caracteres, inclusive espaços)
 *
 * Cada "letra" é um code point (emoji não é cortado ao meio).
 */
public final class LetterFx {
    private LetterFx() {}

    public static final String[] MODES = {"solid", "alt", "grad", "rainbow", "words", "custom"};

    public static boolean validMode(String m) {
        for (String s : MODES) if (s.equals(m)) return true;
        return false;
    }

    /** Cor de cada code point do texto, em ARGB. custom pode ser null; 0 em custom = "usar a cor normal". */
    public static int[] colors(String text, String mode, int c1, int c2, int[] custom, int base) {
        int[] cps = text.codePoints().toArray();
        int[] out = new int[cps.length];
        int total = 0;
        for (int cp : cps) if (!Character.isWhitespace(cp)) total++;
        int k = 0, word = -1;
        boolean inWord = false;
        for (int i = 0; i < cps.length; i++) {
            boolean space = Character.isWhitespace(cps[i]);
            if (space) { inWord = false; out[i] = base; }
            else {
                if (!inWord) { word++; inWord = true; }
                int c;
                switch (mode) {
                    case "alt": c = (k % 2 == 0) ? c1 : c2; break;
                    case "words": c = (word % 2 == 0) ? c1 : c2; break;
                    case "grad": c = lerp(c1, c2, total <= 1 ? 0.0 : (double) k / (total - 1)); break;
                    case "rainbow": c = hsv(360.0 * k / Math.max(total, 1)); break;
                    case "custom": c = (custom != null && i < custom.length && custom[i] != 0) ? custom[i] : base; break;
                    default: c = base;
                }
                out[i] = c;
                k++;
            }
            if (mode.equals("custom") && space && custom != null && i < custom.length && custom[i] != 0) out[i] = custom[i];
        }
        return out;
    }

    static int lerp(int a, int b, double t) {
        int r = (int) Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xff000000 | (r << 16) | (g << 8) | bl;
    }

    /** Matiz 0..360, saturação 0.85, brilho 1. */
    static int hsv(double h) {
        double s = 0.85, v = 1.0;
        h = ((h % 360) + 360) % 360;
        double c = v * s, x = c * (1 - Math.abs((h / 60.0) % 2 - 1)), m = v - c, r, g, b;
        if (h < 60) { r = c; g = x; b = 0; }
        else if (h < 120) { r = x; g = c; b = 0; }
        else if (h < 180) { r = 0; g = c; b = x; }
        else if (h < 240) { r = 0; g = x; b = c; }
        else if (h < 300) { r = x; g = 0; b = c; }
        else { r = c; g = 0; b = x; }
        return 0xff000000 | (((int) Math.round((r + m) * 255)) << 16) | (((int) Math.round((g + m) * 255)) << 8) | (int) Math.round((b + m) * 255);
    }
}
