package com.treinadores.flutuantes;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

/** Tela cheia: aqui voce importa o backup, edita treinadores e troca fotos. */
public class EditorActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> pending;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        web = new WebView(this);
        setContentView(web);
        Web.setup(this, web, (cb, intent) -> {
            if (pending != null) {
                pending.onReceiveValue(null);
            }
            pending = cb;
            try {
                startActivityForResult(intent, 7);
                return true;
            } catch (Exception e) {
                pending = null;
                return false;
            }
        }, this::recreate); // se o processo da pagina cair, reabre a tela em vez de fechar o app
        // "#cores" = abrir direto o seletor de cores (botao da tela inicial)
        boolean cores = b == null && getIntent().getBooleanExtra("cores", false);
        web.loadUrl(Web.URL + (cores ? "#cores" : ""));
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        // evita dois lugares mexendo nos mesmos dados ao mesmo tempo
        if (BubbleService.inst != null) {
            BubbleService.inst.collapse();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == 7) {
            if (pending != null) {
                Uri[] result = null;
                if (res == RESULT_OK && data != null && data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    result = new Uri[n];
                    for (int k = 0; k < n; k++) result[k] = data.getClipData().getItemAt(k).getUri();
                } else {
                    result = WebChromeClient.FileChooserParams.parseResult(res, data);
                }
                pending.onReceiveValue(result);
                pending = null;
            }
        } else {
            super.onActivityResult(req, res, data);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause(); // videos e timers param quando a tela some
        Web.dirty = true;
    }

    @Override
    protected void onDestroy() {
        if (pending != null) {
            pending.onReceiveValue(null); // nao deixa o seletor de arquivos esperando para sempre
            pending = null;
        }
        web.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
