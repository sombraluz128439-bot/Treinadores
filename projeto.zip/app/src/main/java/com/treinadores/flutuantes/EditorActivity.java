package com.treinadores.flutuantes;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

/** Tela cheia: aqui voce importa o backup, edita treinadores e troca fotos. */
public class EditorActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> pending;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        web = new WebView(this);
        setContentView(web);
        Web.setup(this, web, (cb, intent) -> {
            if (pending != null) {
                pending.onReceiveValue(null);
            }
            pending = cb;
            try {
                startActivityForResult(intent, 7);
                return true;
            } catch (Exception e) {
                pending = null;
                return false;
            }
        });
        web.addJavascriptInterface(new PresBridge(), "AndroidWin");
        web.loadUrl(Web.URL);
    }

    /** Ponte chamada pelo botao unico da apresentacao (index.html): AndroidWin.presFull(true/false). */
    public class PresBridge {
        @JavascriptInterface
        public void presFull(final boolean on) {
            runOnUiThread(() -> setImersivo(on));
        }
    }

    /** Esconde (ou mostra) a barra de status e a de navegacao. Deslizar da borda traz as barras por um instante. */
    @SuppressWarnings("deprecation")
    private void setImersivo(boolean on) {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c == null) {
                return;
            }
            if (on) {
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsets.Type.systemBars());
            } else {
                c.show(WindowInsets.Type.systemBars());
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(on
                ? View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                : View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // evita dois lugares mexendo nos mesmos dados ao mesmo tempo
        if (BubbleService.inst != null) {
            BubbleService.inst.collapse();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == 7) {
            if (pending != null) {
                Uri[] result = null;
                if (res == RESULT_OK && data != null && data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    result = new Uri[n];
                    for (int k = 0; k < n; k++) result[k] = data.getClipData().getItemAt(k).getUri();
                } else {
                    result = WebChromeClient.FileChooserParams.parseResult(res, data);
                }
                pending.onReceiveValue(result);
                pending = null;
            }
        } else {
            super.onActivityResult(req, res, data);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Web.dirty = true;
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
