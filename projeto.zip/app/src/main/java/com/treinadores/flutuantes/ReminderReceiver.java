package com.treinadores.flutuantes;
import android.app.NotificationManager;
import android.content.*;
import android.util.Log;
public class ReminderReceiver extends BroadcastReceiver {
    private static final java.util.concurrent.ExecutorService WORK=java.util.concurrent.Executors.newSingleThreadExecutor();
    @Override public void onReceive(Context context,Intent intent) {
        final PendingResult pending=goAsync();final Context app=context.getApplicationContext();
        final String action=intent.getAction()==null?"":intent.getAction();final int id=intent.getIntExtra("id",-1);final int minutes=intent.getIntExtra("minutes",10);
        WORK.execute(()->{try {
            switch(action) {
                case "com.treinadores.REMINDER": ReminderStore.fire(app,id);break;
                case "com.treinadores.SNOOZE": ReminderStore.snooze(app,id,minutes);break;       // botão "Adiar": só este lembrete
                case "com.treinadores.SNOOZE_FIRE": ReminderStore.fireSnooze(app,id);break;
                case "com.treinadores.DISMISS": app.getSystemService(NotificationManager.class).cancel("trainer",id);break; // "Só fechar" / "Dispensar"
                default: ReminderStore.reschedule(app);
            }
        }catch(Exception e){Log.e("TreinadoresLembretes","Falha ao processar lembrete",e);}finally{pending.finish();}});
    }
}
