package com.treinadores.flutuantes;
import android.content.*;
import android.util.Log;
public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent) {
        try {
            if("com.treinadores.REMINDER".equals(intent.getAction())) ReminderStore.fire(context,intent.getIntExtra("id",-1));
            else ReminderStore.reschedule(context);
        } catch(Exception e) { Log.e("TreinadoresLembretes","Falha ao processar lembrete",e); }
    }
}
