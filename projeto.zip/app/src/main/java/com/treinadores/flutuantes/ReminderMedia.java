package com.treinadores.flutuantes;

import android.content.Context;
import android.graphics.*;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.database.Cursor;
import org.json.*;
import java.io.*;
import java.util.UUID;

/** Arquivos privados: não depende de permissão geral de armazenamento. */
public final class ReminderMedia {
    private ReminderMedia() {}
    static File dir(Context c) {File d=new File(c.getFilesDir(),"reminder_media");if(!d.exists()&&!d.mkdirs())throw new IllegalStateException("Não foi possível criar a pasta de mídias.");return d;}
    static File file(Context c,String name) {if(name==null||!name.matches("[a-f0-9-]+\\.(jpg|png|gif|webp|mp4|webm|mov|mp3|wav|ogg|m4a|bin)"))return null;return new File(dir(c),name);}
    static String mime(String name) {String ext=name.substring(name.lastIndexOf('.')+1);switch(ext){case "jpg":return "image/jpeg";case "png":return "image/png";case "gif":return "image/gif";case "webp":return "image/webp";case "mp4":return "video/mp4";case "mov":return "video/quicktime";case "webm":return "video/webm";case "mp3":return "audio/mpeg";case "wav":return "audio/wav";case "ogg":return "audio/ogg";case "m4a":return "audio/mp4";default:return "application/octet-stream";}}
    static JSONObject importUri(Context c,Uri uri,boolean avatar) throws Exception {
        String type=c.getContentResolver().getType(uri);if(type==null)throw new IOException("O provedor não informou o tipo deste arquivo.");
        if(!(type.startsWith("image/")||type.startsWith("video/")||type.startsWith("audio/")))throw new IOException("Escolha uma imagem, um vídeo ou um áudio.");
        if(avatar&&!type.startsWith("image/"))throw new IOException("A foto do treinador precisa ser uma imagem.");
        String ext;switch(type){case "image/jpeg":ext="jpg";break;case "image/png":ext="png";break;case "image/gif":ext="gif";break;case "image/webp":ext="webp";break;case "video/mp4":ext="mp4";break;case "video/webm":ext="webm";break;case "video/quicktime":ext="mov";break;case "audio/mpeg":ext="mp3";break;case "audio/wav":case "audio/x-wav":ext="wav";break;case "audio/ogg":case "application/ogg":ext="ogg";break;case "audio/mp4":case "audio/x-m4a":ext="m4a";break;default:ext="bin";}
        String name="Mídia";try(Cursor q=c.getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(q!=null&&q.moveToFirst())name=q.getString(0);}
        File out=new File(dir(c),UUID.randomUUID().toString()+"."+ext);long bytes=0;
        try(InputStream in=c.getContentResolver().openInputStream(uri);OutputStream dest=new FileOutputStream(out)){
            if(in==null)throw new IOException("Não foi possível ler o arquivo.");byte[] buffer=new byte[65536];int n;
            while((n=in.read(buffer))!=-1){if(dir(c).getUsableSpace()<n+1048576L)throw new IOException("Espaço insuficiente no aparelho.");dest.write(buffer,0,n);bytes+=n;}
        }catch(Exception e){out.delete();throw e;}
        try(OutputStream meta=new FileOutputStream(new File(out.getAbsolutePath()+".mime"))){meta.write(type.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
        return new JSONObject().put("file",out.getName()).put("name",name).put("mime",type).put("bytes",bytes).put("caption","");
    }
    static android.webkit.WebResourceResponse response(Context c,android.webkit.WebResourceRequest request) {
        String name=request.getUrl().getPath().substring("/media/".length());File f=file(c,name);
        try {
            if(f==null||!f.isFile())return responseError(404,"Not Found",null);
            String contentType=mime(name);File meta=new File(f.getAbsolutePath()+".mime");
            if(meta.isFile()){try(InputStream in=new FileInputStream(meta)){byte[] buf=new byte[128];int n=in.read(buf);if(n>0){String type=new String(buf,0,n,java.nio.charset.StandardCharsets.UTF_8);if(type.matches("(image|video|audio)/[a-zA-Z0-9.+-]+"))contentType=type;}}}
            long size=f.length(),start=0,end=size-1;String range=null;
            for(java.util.Map.Entry<String,String> h:request.getRequestHeaders().entrySet())if(h.getKey().equalsIgnoreCase("Range"))range=h.getValue();
            boolean partial=range!=null;
            if(partial){if(!range.matches("bytes=[0-9]*-[0-9]*"))return responseError(416,"Range Not Satisfiable","bytes */"+size);
                String[] parts=range.substring(6).split("-",-1);if(parts[0].isEmpty()){long suffix=Long.parseLong(parts[1]);if(suffix<=0)return responseError(416,"Range Not Satisfiable","bytes */"+size);start=Math.max(0,size-suffix);}else{start=Long.parseLong(parts[0]);if(!parts[1].isEmpty())end=Math.min(end,Long.parseLong(parts[1]));}
                if(start>=size||start>end)return responseError(416,"Range Not Satisfiable","bytes */"+size);
            }
            final long length=Math.max(0,end-start+1);final FileInputStream in=new FileInputStream(f);in.getChannel().position(start);
            InputStream limited=new FilterInputStream(in){long left=length;@Override public int read() throws IOException {if(left<=0)return -1;int b=super.read();if(b>=0)left--;return b;}@Override public int read(byte[] b,int off,int len) throws IOException {if(left<=0)return -1;int n=in.read(b,off,(int)Math.min(len,left));if(n>0)left-=n;return n;}@Override public long skip(long n) throws IOException {long skipped=in.skip(Math.min(n,left));left-=skipped;return skipped;}@Override public int available() throws IOException {return (int)Math.min(left,in.available());}};
            java.util.Map<String,String> headers=new java.util.HashMap<>();headers.put("Accept-Ranges","bytes");headers.put("Content-Length",Long.toString(length));headers.put("Cache-Control","no-store");if(partial)headers.put("Content-Range","bytes "+start+"-"+end+"/"+size);
            return new android.webkit.WebResourceResponse(contentType,null,partial?206:200,partial?"Partial Content":"OK",headers,limited);
        }catch(Exception e){return responseError(404,"Not Found",null);}
    }
    private static android.webkit.WebResourceResponse responseError(int code,String reason,String range){java.util.Map<String,String> headers=new java.util.HashMap<>();if(range!=null)headers.put("Content-Range",range);return new android.webkit.WebResourceResponse("text/plain","UTF-8",code,reason,headers,new ByteArrayInputStream(new byte[0]));}
    static Bitmap image(Context c,JSONObject media,int max) {
        if(media==null)return null;File f=file(c,media.optString("file"));if(f==null||!f.isFile())return null;
        try{
            if(media.optString("mime").startsWith("video/")){
                try(MediaMetadataRetriever r=new MediaMetadataRetriever()){r.setDataSource(f.getAbsolutePath());return r.getScaledFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC,max,Math.max(1,max*9/16));}
            }
            if(!media.optString("mime").startsWith("image/"))return null;
            BitmapFactory.Options opt=new BitmapFactory.Options();opt.inJustDecodeBounds=true;BitmapFactory.decodeFile(f.getAbsolutePath(),opt);opt.inSampleSize=1;
            while(Math.max(opt.outWidth,opt.outHeight)/opt.inSampleSize>max*2)opt.inSampleSize*=2;
            opt.inJustDecodeBounds=false;Bitmap b=BitmapFactory.decodeFile(f.getAbsolutePath(),opt);if(b==null)return null;
            if(Math.max(b.getWidth(),b.getHeight())>max){float s=(float)max/Math.max(b.getWidth(),b.getHeight());Bitmap scaled=Bitmap.createScaledBitmap(b,Math.max(1,Math.round(b.getWidth()*s)),Math.max(1,Math.round(b.getHeight()*s)),true);if(scaled!=b)b.recycle();return scaled;}return b;
        }catch(Exception|OutOfMemoryError e){android.util.Log.w("ReminderMedia","Prévia de mídia indisponível",e);return null;}
    }
    static JSONObject firstVisual(JSONObject o) {JSONArray a=o.optJSONArray("media");if(a!=null)for(int i=0;i<a.length();i++){JSONObject m=a.optJSONObject(i);if(m!=null&&(m.optString("mime").startsWith("image/")||m.optString("mime").startsWith("video/")))return m;}return null;}
}
