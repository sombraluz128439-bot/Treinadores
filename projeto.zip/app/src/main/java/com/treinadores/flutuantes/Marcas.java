package com.treinadores.flutuantes;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Segundo balao flutuante (📍): coloca emojis, setas, circulos e quadrados POR CIMA de qualquer app
 * (ex.: um app de xadrez). Cada marca e uma janelinha propria, que fica na tela ate voce apertar
 * "Remover". Da para mudar tamanho, giro, opacidade, espessura, cor e fundo, mover e travar.
 */
final class Marcas {
    static final int T_EMOJI = 0;
    static final int T_SETA = 1;
    static final int T_CIRCULO = 2;
    static final int T_QUADRADO = 3;

    private static final int MATCH = -1;
    private static final int WRAP = -2;
    private static final int AMBAR = 0xFFFFB300;
    private static final int CHIP = 0xFF2A2F4A;

    private static final int[] CORES = {
        0xFFFF3B30, 0xFFFF9500, 0xFFFFCC00, 0xFF34C759, 0xFF00F0FF, 0xFF0A84FF,
        0xFFAF52DE, 0xFFFF2D92, 0xFFFFFFFF, 0xFF8E8E93, 0xFF000000
    };

    private static final String[] GRUPOS = {"✅❌", "⭐", "😀", "👍", "⬆️", "🎯"};
    private static final String[][] EMOJIS = {
        {"✅", "❌", "✔️", "✖️", "⭕", "❗", "❓", "⚠️", "🚫", "❎", "🆗", "💯"},
        {"⭐", "🌟", "✨", "💫", "🏆", "🥇", "🥈", "🥉", "🎖️", "👑", "🎉", "🔥"},
        {"😀", "😎", "😢", "😡", "🤔", "😱", "🥳", "😴", "😅", "🤯", "😬", "🙂"},
        {"👍", "👎", "👏", "🙌", "👆", "👇", "👈", "👉", "🤝", "💪", "🙏", "✋"},
        {"⬆️", "⬇️", "⬅️", "➡️", "↗️", "↘️", "↙️", "↖️", "🔄", "↩️", "⤴️", "⤵️"},
        {"♟️", "♞", "♛", "♚", "🎯", "💡", "🚩", "📌", "📍", "❤️", "💎", "⚡"}
    };

    /** Uma marca na tela. */
    static final class Mark {
        int type;
        String text = "";
        int color;
        int bg;
        int sizeDp;
        int rot;
        int alpha;
        int thick;
        int tint;
        MarkView view;
        WindowManager.LayoutParams lp;
        boolean attached;
    }

    private interface IntCb {
        void run(int v);
    }

    private final Context ctx;
    private final WindowManager wm;
    private final SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private float dp;

    private TextView ball;
    private WindowManager.LayoutParams ballLp;
    private boolean ballOn;

    private LinearLayout panel;
    private WindowManager.LayoutParams panelLp;
    private boolean panelOn;
    private boolean typing;
    private int savedPy;

    private TextView status;
    private LinearLayout gridBox;
    private LinearLayout swatchBox;
    private EditText edit;
    private Slider slSize;
    private Slider slRot;
    private Slider slAlpha;
    private Slider slThick;
    private Slider slHue;
    private TextView chipHide;
    private TextView chipLock;
    private TextView chipClear;
    private TextView chipMain;
    private TextView chipBg;
    private TextView[] chipTint;

    private final ArrayList<Mark> marks = new ArrayList<>();
    private final Mark def = new Mark();
    private Mark sel;
    private boolean hidden;
    private boolean locked;
    private boolean confirmaLimpar;
    private int grupo;
    private int alvo;

    Marcas(Context ctx, WindowManager wm) {
        this.ctx = ctx;
        this.wm = wm;
        this.dp = ctx.getResources().getDisplayMetrics().density;
        this.prefs = ctx.getSharedPreferences("marcas", Context.MODE_PRIVATE);
        def.color = prefs.getInt("dc", 0xFFFF3B30);
        def.bg = prefs.getInt("db", 0);
        def.sizeDp = prefs.getInt("dz", 72);
        def.alpha = prefs.getInt("da", 100);
        def.thick = prefs.getInt("dw", 12);
    }

    // ------------------------------------------------------------------ ciclo de vida

    void start() {
        try {
            buildBall();
            buildPanel();
            wm.addView(ball, ballLp);
            ballOn = true;
            restore();
            bringFront();
        } catch (Exception e) {
            // se algo falhar, o resto do app continua funcionando
        }
    }

    void destroy() {
        try {
            closePanel();
        } catch (Exception e) {
            // ignora
        }
        for (Mark m : marks) {
            detach(m);
        }
        try {
            if (ballOn) {
                wm.removeView(ball);
            }
        } catch (Exception e) {
            // ignora
        }
        ballOn = false;
    }

    void onConfig() {
        try {
            dp = ctx.getResources().getDisplayMetrics().density;
            if (ballOn) {
                clamp(ballLp);
                upd(ball, ballLp);
            }
            if (panelOn) {
                sizePanel();
                upd(panel, panelLp);
            }
            for (Mark m : marks) {
                refresh(m);
            }
        } catch (Exception e) {
            // ignora
        }
    }

    // ------------------------------------------------------------------ utilidades

    private int px(float v) {
        return (int) (v * dp + 0.5f);
    }

    private int[] screen() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Rect b = wm.getCurrentWindowMetrics().getBounds();
                return new int[]{b.width(), b.height()};
            }
            DisplayMetrics m = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(m);
            return new int[]{m.widthPixels, m.heightPixels};
        } catch (Exception e) {
            DisplayMetrics m2 = ctx.getResources().getDisplayMetrics();
            return new int[]{m2.widthPixels, m2.heightPixels};
        }
    }

    private void clamp(WindowManager.LayoutParams p) {
        int[] s = screen();
        p.x = Math.max(0, Math.min(p.x, s[0] - p.width));
        p.y = Math.max(0, Math.min(p.y, s[1] - p.height));
    }

    private WindowManager.LayoutParams lp(int w, int h, boolean touchable) {
        int f = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (!touchable) {
            f |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        return p;
    }

    private void upd(View v, WindowManager.LayoutParams p) {
        try {
            wm.updateViewLayout(v, p);
        } catch (Exception e) {
            // janela nao esta na tela
        }
    }

    private LinearLayout.LayoutParams lpL(int w, int h, float wt, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, wt);
        p.setMargins(px(l), px(t), px(r), px(b));
        return p;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(ctx);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private TextView chip(String t, float sp, View.OnClickListener l) {
        TextView v = new TextView(ctx);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(0xFFFFFFFF);
        v.setGravity(Gravity.CENTER);
        v.setPadding(px(8), px(6), px(8), px(6));
        tint(v, false);
        v.setOnClickListener(l);
        return v;
    }

    private void tint(TextView v, boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? AMBAR : CHIP);
        g.setCornerRadius(px(10));
        v.setBackground(g);
        v.setTextColor(on ? 0xFF000000 : 0xFFFFFFFF);
    }

    private TextView label(String t) {
        TextView v = new TextView(ctx);
        v.setText(t);
        v.setTextSize(11);
        v.setTextColor(0xFFB0B6D0);
        v.setPadding(px(4), px(8), 0, px(2));
        return v;
    }

    /** Arrasta uma janela (e toca se nao mexeu). */
    private void drag(View handle, final WindowManager.LayoutParams p, final View win,
                      final Runnable tap, final Runnable end) {
        final float[] st = new float[4];
        final boolean[] moved = new boolean[1];
        handle.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    st[0] = e.getRawX();
                    st[1] = e.getRawY();
                    st[2] = p.x;
                    st[3] = p.y;
                    moved[0] = false;
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - st[0];
                    float dy = e.getRawY() - st[1];
                    if (!moved[0] && (Math.abs(dx) > px(8) || Math.abs(dy) > px(8))) {
                        moved[0] = true;
                    }
                    if (moved[0]) {
                        p.x = (int) (st[2] + dx);
                        p.y = (int) (st[3] + dy);
                        clamp(p);
                        upd(win, p);
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                    if (!moved[0]) {
                        if (tap != null) {
                            tap.run();
                        }
                    } else if (end != null) {
                        end.run();
                    }
                    break;
                default:
                    break;
            }
            return true;
        });
    }

    // ------------------------------------------------------------------ o balao 📍

    private void buildBall() {
        ball = new TextView(ctx);
        ball.setText("📍");
        ball.setTextSize(22);
        ball.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xE6171A2E);
        bg.setStroke(px(3), AMBAR);
        ball.setBackground(bg);
        int size = px(48);
        ballLp = lp(size, size, true);
        ballLp.x = prefs.getInt("mbx", px(12));
        ballLp.y = prefs.getInt("mby", px(290));
        clamp(ballLp);
        drag(ball, ballLp, ball, this::togglePanel, () ->
            prefs.edit().putInt("mbx", ballLp.x).putInt("mby", ballLp.y).apply());
    }

    private void togglePanel() {
        if (panelOn) {
            closePanel();
        } else {
            openPanel();
        }
    }

    // ------------------------------------------------------------------ a janela de ferramentas

    private void sizePanel() {
        int[] s = screen();
        panelLp.width = Math.min(px(340), s[0] - px(12));
        panelLp.height = Math.max(px(220), Math.min(px(470), (int) (s[1] * 0.62f)));
        clamp(panelLp);
    }

    private void openPanel() {
        if (panelOn) {
            return;
        }
        int[] s = screen();
        sizePanel();
        panelLp.x = prefs.getInt("mpx", (s[0] - panelLp.width) / 2);
        panelLp.y = prefs.getInt("mpy", px(40));
        panelLp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_UNSPECIFIED;
        clamp(panelLp);
        try {
            wm.addView(panel, panelLp);
            panelOn = true;
        } catch (Exception e) {
            return;
        }
        syncUi();
        ui.post(this::frontBall);
    }

    private void closePanel() {
        if (!panelOn) {
            return;
        }
        setTyping(false);
        confirmaLimpar = false;
        try {
            wm.removeView(panel);
        } catch (Exception e) {
            // ignora
        }
        panelOn = false;
        select(null);
    }

    /** Mantem a janela de ferramentas e o balao por cima das marcas (feito logo depois do toque). */
    private void bringFront() {
        ui.post(() -> {
            try {
                if (panelOn && !typing) {
                    wm.removeView(panel);
                    wm.addView(panel, panelLp);
                }
                frontBall();
            } catch (Exception e) {
                // ignora
            }
        });
    }

    private void frontBall() {
        try {
            if (ballOn) {
                wm.removeView(ball);
                wm.addView(ball, ballLp);
            }
        } catch (Exception e) {
            // ignora
        }
    }

    // Janela normal nao rouba o foco do app de baixo. Para digitar, liga o foco.
    private void setTyping(boolean on) {
        if (!panelOn) {
            typing = false;
            return;
        }
        if (on == typing) {
            return;
        }
        typing = on;
        if (on) {
            savedPy = panelLp.y;
            panelLp.y = 0;
            panelLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
        } else {
            try {
                InputMethodManager imm = (InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(edit.getWindowToken(), 0);
            } catch (Exception e) {
                // ignora
            }
            edit.clearFocus();
            panelLp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_UNSPECIFIED;
            panelLp.y = savedPy;
        }
        upd(panel, panelLp);
        if (on) {
            ui.postDelayed(() -> {
                try {
                    edit.requestFocus();
                    InputMethodManager imm2 = (InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm2.showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT);
                } catch (Exception e) {
                    // ignora
                }
            }, 150);
        }
    }

    private void buildPanel() {
        panel = new LinearLayout(ctx) {
            @Override
            public boolean dispatchKeyEvent(KeyEvent ev) {
                if (typing && ev.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                    if (ev.getAction() == KeyEvent.ACTION_UP) {
                        setTyping(false);
                    }
                    return true;
                }
                return super.dispatchKeyEvent(ev);
            }
        };
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF2171A2E);
        bg.setCornerRadius(px(14));
        bg.setStroke(px(2), AMBAR);
        panel.setBackground(bg);
        panel.setPadding(px(6), px(6), px(6), px(6));

        // cabecalho: arrastar + fechar
        LinearLayout head = row();
        TextView title = new TextView(ctx);
        title.setText("📍 Marcadores · arraste aqui");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(13);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(px(6), 0, 0, 0);
        head.addView(title, new LinearLayout.LayoutParams(0, px(36), 1f));
        head.addView(chip("▾ fechar", 12, v -> closePanel()), new LinearLayout.LayoutParams(WRAP, px(36)));
        panel.addView(head, new LinearLayout.LayoutParams(MATCH, WRAP));

        panelLp = lp(px(300), px(400), true);
        drag(title, panelLp, panel, null, () ->
            prefs.edit().putInt("mpx", panelLp.x).putInt("mpy", panelLp.y).apply());

        ScrollView sv = new ScrollView(ctx);
        LinearLayout c = new LinearLayout(ctx);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(px(2), px(2), px(2), px(10));
        sv.addView(c);
        panel.addView(sv, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        status = new TextView(ctx);
        status.setTextSize(12);
        status.setTextColor(AMBAR);
        status.setPadding(px(4), px(4), px(4), px(2));
        c.addView(status);

        // emojis
        c.addView(label("EMOJIS (toque para colocar na tela)"));
        HorizontalScrollView hs = new HorizontalScrollView(ctx);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout hr = row();
        for (int i = 0; i < GRUPOS.length; i++) {
            final int gi = i;
            hr.addView(chip(GRUPOS[i], 16, v -> {
                grupo = gi;
                buildGrid();
            }), lpL(WRAP, px(40), 0, 2, 2, 2, 2));
        }
        hs.addView(hr);
        c.addView(hs, new LinearLayout.LayoutParams(MATCH, WRAP));
        gridBox = new LinearLayout(ctx);
        gridBox.setOrientation(LinearLayout.VERTICAL);
        c.addView(gridBox, new LinearLayout.LayoutParams(MATCH, WRAP));
        buildGrid();

        // formas
        c.addView(label("FORMAS PARA APONTAR"));
        LinearLayout shapes = row();
        shapes.addView(chip("➜ Seta", 14, v -> addMark(T_SETA, "")), lpL(0, px(42), 1f, 2, 0, 2, 0));
        shapes.addView(chip("◯ Círculo", 14, v -> addMark(T_CIRCULO, "")), lpL(0, px(42), 1f, 2, 0, 2, 0));
        shapes.addView(chip("▢ Quadrado", 14, v -> addMark(T_QUADRADO, "")), lpL(0, px(42), 1f, 2, 0, 2, 0));
        c.addView(shapes, new LinearLayout.LayoutParams(MATCH, WRAP));

        // digitar emoji ou texto
        c.addView(label("DIGITAR OUTRO EMOJI / LETRA / NÚMERO"));
        LinearLayout typed = row();
        edit = new EditText(ctx);
        edit.setHint("ex.: 🐴 ou A1 ou 3");
        edit.setHintTextColor(0xFF7B819E);
        edit.setTextColor(0xFFFFFFFF);
        edit.setTextSize(16);
        edit.setSingleLine(true);
        edit.setImeOptions(EditorInfo.IME_ACTION_DONE);
        edit.setPadding(px(10), px(6), px(10), px(6));
        GradientDrawable eg = new GradientDrawable();
        eg.setColor(0xFF10132A);
        eg.setCornerRadius(px(10));
        eg.setStroke(px(1), 0xFF4A5070);
        edit.setBackground(eg);
        edit.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN && !typing) {
                setTyping(true);
            }
            return false;
        });
        edit.setOnEditorActionListener((tv, actionId, ev) -> {
            addTyped();
            return true;
        });
        typed.addView(edit, lpL(0, px(44), 1f, 2, 0, 4, 0));
        typed.addView(chip("＋ Colocar", 13, v -> addTyped()), lpL(WRAP, px(44), 0, 0, 0, 2, 0));
        c.addView(typed, new LinearLayout.LayoutParams(MATCH, WRAP));

        // estilo
        c.addView(label("ESTILO (vale para a marca selecionada e para as próximas)"));
        slSize = new Slider(c, "Tamanho", 24, 400, " dp", v -> {
            def.sizeDp = v;
            if (sel != null) {
                sel.sizeDp = v;
                refresh(sel);
            }
        });
        slRot = new Slider(c, "Giro", 0, 359, "°", v -> {
            if (sel != null) {
                sel.rot = v;
                refresh(sel);
            }
        });
        slAlpha = new Slider(c, "Opacidade", 15, 100, "%", v -> {
            def.alpha = v;
            if (sel != null) {
                sel.alpha = v;
                refresh(sel);
            }
        });
        slThick = new Slider(c, "Espessura (seta/círculo/quadrado)", 3, 40, "%", v -> {
            def.thick = v;
            if (sel != null) {
                sel.thick = v;
                refresh(sel);
            }
        });

        // colorir emoji (emoji colorido tem cor propria: aqui ela e trocada pela que voce escolher)
        c.addView(label("COLORIR O EMOJI (toque num emoji na tela e escolha a cor abaixo)"));
        LinearLayout tm = row();
        String[] tn = {"Original", "Colorir", "Sólido"};
        chipTint = new TextView[3];
        for (int i = 0; i < 3; i++) {
            final int k = i;
            chipTint[i] = chip(tn[i], 13, v -> setTint(k));
            tm.addView(chipTint[i], lpL(0, px(40), 1f, 2, 0, 2, 0));
        }
        c.addView(tm, new LinearLayout.LayoutParams(MATCH, WRAP));
        TextView tdica = new TextView(ctx);
        tdica.setText("Colorir: troca a cor mas mantém os detalhes. Sólido: pinta tudo de uma cor só.");
        tdica.setTextSize(11);
        tdica.setTextColor(0xFF8A90AE);
        tdica.setPadding(px(4), px(2), px(4), 0);
        c.addView(tdica);

        // cores
        c.addView(label("COR"));
        LinearLayout tg = row();
        chipMain = chip("Cor (emoji/forma/letra)", 12, v -> {
            alvo = 0;
            buildSwatches();
            syncUi();
        });
        chipBg = chip("Fundo atrás", 12, v -> {
            alvo = 1;
            buildSwatches();
            syncUi();
        });
        tg.addView(chipMain, lpL(0, px(38), 1f, 2, 0, 2, 0));
        tg.addView(chipBg, lpL(0, px(38), 1f, 2, 0, 2, 0));
        c.addView(tg, new LinearLayout.LayoutParams(MATCH, WRAP));
        HorizontalScrollView sh = new HorizontalScrollView(ctx);
        sh.setHorizontalScrollBarEnabled(false);
        swatchBox = row();
        sh.addView(swatchBox);
        c.addView(sh, new LinearLayout.LayoutParams(MATCH, WRAP));
        slHue = new Slider(c, "Matiz (qualquer cor)", 0, 360, "°", v ->
            setColor(Color.HSVToColor(new float[]{v, 1f, 1f})));
        buildSwatches();

        // acoes
        c.addView(label("AÇÕES"));
        LinearLayout a1 = row();
        a1.addView(chip("⧉ Duplicar", 13, v -> duplicate()), lpL(0, px(42), 1f, 2, 0, 2, 0));
        a1.addView(chip("🗑 Remover esta", 13, v -> removeSel()), lpL(0, px(42), 1f, 2, 0, 2, 0));
        c.addView(a1, new LinearLayout.LayoutParams(MATCH, WRAP));
        chipClear = chip("🧹 Remover todas", 13, v -> clearAll());
        c.addView(chipClear, lpL(MATCH, px(42), 0, 2, 4, 2, 0));
        LinearLayout a2 = row();
        chipHide = chip("👁 Ocultar todas", 13, v -> setHidden(!hidden));
        chipLock = chip("🔒 Travar (toque passa)", 13, v -> setLocked(!locked));
        a2.addView(chipHide, lpL(0, px(42), 1f, 2, 0, 2, 0));
        a2.addView(chipLock, lpL(0, px(42), 1f, 2, 0, 2, 0));
        c.addView(a2, lpL(MATCH, WRAP, 0, 0, 4, 0, 0));
        TextView dica = new TextView(ctx);
        dica.setText("Dica: toque numa marca para selecioná-la, arraste para mudar de lugar. "
            + "Ela só some quando você apertar Remover.");
        dica.setTextSize(11);
        dica.setTextColor(0xFF8A90AE);
        dica.setPadding(px(4), px(8), px(4), 0);
        c.addView(dica);

        refreshChips();
        syncUi();
    }

    private void buildGrid() {
        gridBox.removeAllViews();
        String[] list = EMOJIS[Math.max(0, Math.min(EMOJIS.length - 1, grupo))];
        LinearLayout r = null;
        for (int i = 0; i < list.length; i++) {
            if (i % 6 == 0) {
                r = row();
                gridBox.addView(r, lpL(MATCH, WRAP, 0, 0, 2, 0, 2));
            }
            final String em = list[i];
            r.addView(chip(em, 22, v -> addMark(T_EMOJI, em)), lpL(0, px(46), 1f, 2, 0, 2, 0));
        }
    }

    private void buildSwatches() {
        swatchBox.removeAllViews();
        if (alvo == 1) {
            TextView none = chip("∅", 16, v -> setColor(0));
            swatchBox.addView(none, lpL(px(34), px(34), 0, 3, 3, 3, 3));
        }
        for (final int col : CORES) {
            View s = new View(ctx);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(col);
            g.setStroke(px(2), 0xFFFFFFFF);
            s.setBackground(g);
            s.setOnClickListener(v -> setColor(col));
            swatchBox.addView(s, lpL(px(34), px(34), 0, 3, 3, 3, 3));
        }
    }

    private void setColor(int col) {
        if (alvo == 0) {
            if (col == 0) {
                return;
            }
            def.color = col;
            if (sel != null) {
                sel.color = col;
                if (sel.type == T_EMOJI && sel.tint == 0 && !soAscii(sel.text)) {
                    sel.tint = 1;
                    refreshChips();
                }
                refresh(sel);
            }
        } else {
            def.bg = col;
            if (sel != null) {
                sel.bg = col;
                refresh(sel);
            }
        }
        save();
    }

    private static boolean soAscii(String t) {
        if (t == null) {
            return true;
        }
        for (int i = 0; i < t.length(); i++) {
            if (t.charAt(i) > 127) {
                return false;
            }
        }
        return true;
    }

    private void setTint(int k) {
        if (sel == null || sel.type != T_EMOJI) {
            status.setText("Toque num emoji na tela para selecioná-lo e depois escolha como pintar");
            return;
        }
        sel.tint = k;
        refresh(sel);
        refreshChips();
        save();
    }

    private void refreshChips() {
        chipHide.setText(hidden ? "👁 Mostrar todas" : "👁 Ocultar todas");
        tint(chipHide, hidden);
        chipLock.setText(locked ? "🔓 Destravar" : "🔒 Travar (toque passa)");
        tint(chipLock, locked);
        tint(chipMain, alvo == 0);
        tint(chipBg, alvo == 1);
        if (chipTint != null) {
            for (int i = 0; i < chipTint.length; i++) {
                tint(chipTint[i], sel != null && sel.type == T_EMOJI && sel.tint == i);
            }
        }
    }

    private String nome(Mark m) {
        switch (m.type) {
            case T_SETA:
                return "seta";
            case T_CIRCULO:
                return "círculo";
            case T_QUADRADO:
                return "quadrado";
            default:
                return m.text == null || m.text.isEmpty() ? "marca" : m.text;
        }
    }

    /** Atualiza sliders e textos conforme a marca selecionada (ou o estilo padrao). */
    private void syncUi() {
        if (status == null || slHue == null) {
            return;
        }
        Mark m = sel != null ? sel : def;
        slSize.set(m.sizeDp);
        slRot.set(sel != null ? sel.rot : 0);
        slAlpha.set(m.alpha);
        slThick.set(m.thick);
        float[] hsv = new float[3];
        int base = alvo == 0 ? m.color : (m.bg != 0 ? m.bg : m.color);
        Color.colorToHSV(base, hsv);
        slHue.set(Math.round(hsv[0]));
        status.setText(sel != null
            ? "Editando: " + nome(sel) + " (toque em outra marca para trocar)"
            : "Nenhuma marca selecionada — o estilo vale para as próximas");
        refreshChips();
    }

    // ------------------------------------------------------------------ marcas

    private void applyFlags(Mark m) {
        int f = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (locked) {
            f |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }
        m.lp.flags = f;
        // Android 12+: janela que deixa o toque passar nao pode ter opacidade acima de 0,8.
        m.lp.alpha = Math.min(m.alpha / 100f, locked ? 0.8f : 1f);
    }

    private Mark newMark(int type, String text) {
        final Mark m = new Mark();
        m.type = type;
        m.text = text == null ? "" : text;
        m.color = def.color;
        m.bg = def.bg;
        m.sizeDp = def.sizeDp;
        m.alpha = def.alpha;
        m.thick = def.thick;
        m.rot = 0;
        m.tint = 0;
        m.view = new MarkView(ctx, m);
        m.lp = lp(px(m.sizeDp), px(m.sizeDp), true);
        applyFlags(m);
        drag(m.view, m.lp, m.view, () -> {
            select(m);
            openPanel();
        }, this::save);
        return m;
    }

    private void attach(Mark m) {
        if (m.attached) {
            return;
        }
        try {
            wm.addView(m.view, m.lp);
            m.attached = true;
        } catch (Exception e) {
            // ignora
        }
    }

    private void detach(Mark m) {
        if (!m.attached) {
            return;
        }
        try {
            wm.removeView(m.view);
        } catch (Exception e) {
            // ignora
        }
        m.attached = false;
    }

    /** Aplica tamanho/opacidade/etc. mantendo o centro da marca no mesmo lugar. */
    private void refresh(Mark m) {
        int old = m.lp.width;
        int size = px(m.sizeDp);
        int cx = m.lp.x + old / 2;
        int cy = m.lp.y + old / 2;
        m.lp.width = size;
        m.lp.height = size;
        m.lp.x = cx - size / 2;
        m.lp.y = cy - size / 2;
        clamp(m.lp);
        applyFlags(m);
        if (m.attached) {
            upd(m.view, m.lp);
        }
        m.view.invalidate();
    }

    /** Coloca a marca nova no meio da area livre (fora da janela de ferramentas). */
    private void place(Mark m) {
        int[] s = screen();
        int size = px(m.sizeDp);
        int n = (marks.size() % 5) - 2;
        int top = 0;
        int bottom = s[1];
        if (panelOn) {
            int pt = panelLp.y;
            int pb = panelLp.y + panelLp.height;
            if (pt > s[1] - pb) {
                bottom = pt;
            } else {
                top = pb;
            }
        }
        m.lp.x = s[0] / 2 - size / 2 + n * px(14);
        m.lp.y = (top + bottom) / 2 - size / 2 + n * px(14);
        clamp(m.lp);
    }

    private void addMark(int type, String text) {
        if (typing) {
            setTyping(false);
        }
        if (hidden) {
            setHidden(false);
        }
        Mark m = newMark(type, text);
        place(m);
        marks.add(m);
        attach(m);
        select(m);
        bringFront();
        save();
    }

    private void addTyped() {
        String t = edit.getText().toString().trim();
        if (t.isEmpty()) {
            return;
        }
        if (t.length() > 12) {
            t = t.substring(0, 12);
        }
        edit.setText("");
        addMark(T_EMOJI, t);
    }

    private void select(Mark m) {
        if (sel != null && sel.view != null) {
            sel.view.sel = false;
            sel.view.invalidate();
        }
        sel = m;
        if (m != null) {
            m.view.sel = true;
            m.view.invalidate();
        }
        syncUi();
    }

    private void removeSel() {
        if (sel == null) {
            return;
        }
        Mark m = sel;
        select(null);
        detach(m);
        marks.remove(m);
        save();
    }

    private void duplicate() {
        if (sel == null) {
            return;
        }
        Mark o = sel;
        Mark m = newMark(o.type, o.text);
        m.color = o.color;
        m.bg = o.bg;
        m.sizeDp = o.sizeDp;
        m.rot = o.rot;
        m.alpha = o.alpha;
        m.thick = o.thick;
        m.tint = o.tint;
        m.lp.width = px(m.sizeDp);
        m.lp.height = px(m.sizeDp);
        m.lp.x = o.lp.x + px(24);
        m.lp.y = o.lp.y + px(24);
        clamp(m.lp);
        applyFlags(m);
        marks.add(m);
        attach(m);
        select(m);
        bringFront();
        save();
    }

    private void clearAll() {
        if (marks.isEmpty()) {
            return;
        }
        if (!confirmaLimpar) {
            confirmaLimpar = true;
            chipClear.setText("Toque de novo para apagar TODAS");
            ui.postDelayed(() -> {
                confirmaLimpar = false;
                chipClear.setText("🧹 Remover todas");
            }, 3000);
            return;
        }
        confirmaLimpar = false;
        chipClear.setText("🧹 Remover todas");
        select(null);
        for (Mark m : marks) {
            detach(m);
        }
        marks.clear();
        save();
    }

    private void setHidden(boolean h) {
        hidden = h;
        for (Mark m : marks) {
            if (h) {
                detach(m);
            } else {
                attach(m);
            }
        }
        if (!h) {
            bringFront();
        }
        refreshChips();
    }

    private void setLocked(boolean l) {
        locked = l;
        for (Mark m : marks) {
            applyFlags(m);
            if (m.attached) {
                upd(m.view, m.lp);
            }
        }
        refreshChips();
        save();
    }

    // ------------------------------------------------------------------ guardar / restaurar

    private void save() {
        try {
            JSONArray a = new JSONArray();
            for (Mark m : marks) {
                JSONObject o = new JSONObject();
                o.put("t", m.type);
                o.put("s", m.text == null ? "" : m.text);
                o.put("c", m.color);
                o.put("b", m.bg);
                o.put("z", m.sizeDp);
                o.put("r", m.rot);
                o.put("a", m.alpha);
                o.put("w", m.thick);
                o.put("n", m.tint);
                o.put("x", m.lp.x);
                o.put("y", m.lp.y);
                a.put(o);
            }
            prefs.edit()
                .putString("lista", a.toString())
                .putBoolean("lock", locked)
                .putInt("dc", def.color)
                .putInt("db", def.bg)
                .putInt("dz", def.sizeDp)
                .putInt("da", def.alpha)
                .putInt("dw", def.thick)
                .apply();
        } catch (Exception e) {
            // ignora
        }
    }

    private void restore() {
        locked = prefs.getBoolean("lock", false);
        try {
            JSONArray a = new JSONArray(prefs.getString("lista", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Mark m = newMark(o.optInt("t", T_EMOJI), o.optString("s", ""));
                m.color = o.optInt("c", def.color);
                m.bg = o.optInt("b", 0);
                m.sizeDp = Math.max(24, Math.min(400, o.optInt("z", 72)));
                m.rot = o.optInt("r", 0);
                m.alpha = Math.max(15, Math.min(100, o.optInt("a", 100)));
                m.thick = Math.max(3, Math.min(40, o.optInt("w", 12)));
                m.tint = Math.max(0, Math.min(2, o.optInt("n", 0)));
                m.lp.width = px(m.sizeDp);
                m.lp.height = px(m.sizeDp);
                m.lp.x = o.optInt("x", 0);
                m.lp.y = o.optInt("y", 0);
                clamp(m.lp);
                applyFlags(m);
                marks.add(m);
                attach(m);
            }
        } catch (Exception e) {
            // lista invalida: comeca vazia
        }
        refreshChips();
    }

    // ------------------------------------------------------------------ controle deslizante

    private final class Slider {
        final SeekBar bar;
        final TextView val;
        final int min;
        final String unit;

        Slider(LinearLayout parent, String name, int min, int max, String unit, IntCb cb) {
            this.min = min;
            this.unit = unit;
            LinearLayout top = row();
            TextView nm = new TextView(ctx);
            nm.setText(name);
            nm.setTextSize(12);
            nm.setTextColor(0xFFFFFFFF);
            val = new TextView(ctx);
            val.setTextSize(12);
            val.setTextColor(AMBAR);
            top.addView(nm, new LinearLayout.LayoutParams(0, WRAP, 1f));
            top.addView(val, new LinearLayout.LayoutParams(WRAP, WRAP));
            parent.addView(top, lpL(MATCH, WRAP, 0, 4, 4, 4, 0));
            bar = new SeekBar(ctx);
            bar.setMax(max - min);
            bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                    val.setText((p + Slider.this.min) + Slider.this.unit);
                    if (fromUser) {
                        cb.run(p + Slider.this.min);
                    }
                }

                @Override
                public void onStartTrackingTouch(SeekBar b) {
                    // nada
                }

                @Override
                public void onStopTrackingTouch(SeekBar b) {
                    save();
                }
            });
            parent.addView(bar, lpL(MATCH, px(34), 0, 0, 0, 0, 0));
        }

        void set(int v) {
            bar.setProgress(Math.max(0, Math.min(bar.getMax(), v - min)));
            val.setText(v + unit);
        }
    }

    // ------------------------------------------------------------------ desenho da marca

    static final class MarkView extends View {
        final Mark m;
        boolean sel;
        private final float d;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dash = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF rect = new RectF();
        private final Paint tintPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Rect src = new Rect();
        private final RectF dst = new RectF();
        private Bitmap gBmp;
        private String gKey;
        private final DashPathEffect dashA;
        private final DashPathEffect dashB;

        MarkView(Context c, Mark mark) {
            super(c);
            m = mark;
            d = c.getResources().getDisplayMetrics().density;
            fill.setStyle(Paint.Style.FILL);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            halo.setStyle(Paint.Style.STROKE);
            halo.setColor(0x66000000);
            halo.setStrokeCap(Paint.Cap.ROUND);
            halo.setStrokeJoin(Paint.Join.ROUND);
            txt.setTextAlign(Paint.Align.CENTER);
            dash.setStyle(Paint.Style.STROKE);
            dash.setStrokeWidth(2 * d);
            dashA = new DashPathEffect(new float[]{8 * d, 6 * d}, 0);
            dashB = new DashPathEffect(new float[]{8 * d, 6 * d}, 7 * d);
        }

        /**
         * Emoji colorido tem a cor dentro do desenho (a cor do texto nao muda nada nele).
         * Entao o glifo e desenhado num bitmap e recolorido com um filtro de cor:
         * tint 1 = Colorir (mantem luz e sombra, troca a cor) ; tint 2 = Solido (uma cor so).
         */
        private void drawTinted(Canvas c, String t, float ts, float cx, float cy, float s) {
            int bw = Math.max(8, Math.min(512, Math.round(s)));
            String key = t + "|" + bw + "|" + Math.round(ts * 10f);
            if (gBmp == null || !key.equals(gKey)) {
                gBmp = Bitmap.createBitmap(bw, bw, Bitmap.Config.ARGB_8888);
                Canvas bc = new Canvas(gBmp);
                float f = bw / s;
                txt.setTextSize(ts * f);
                txt.setColor(0xFFFFFFFF);
                Paint.FontMetrics fm = txt.getFontMetrics();
                bc.drawText(t, bw / 2f, bw / 2f - (fm.ascent + fm.descent) / 2f, txt);
                gKey = key;
            }
            float tr = Color.red(m.color) / 255f;
            float tg = Color.green(m.color) / 255f;
            float tb = Color.blue(m.color) / 255f;
            float[] mm;
            if (m.tint == 2) {
                mm = new float[]{
                    0, 0, 0, 0, tr * 255f,
                    0, 0, 0, 0, tg * 255f,
                    0, 0, 0, 0, tb * 255f,
                    0, 0, 0, 1, 0};
            } else {
                // luz e sombra do emoji viram faixa da cor escolhida: do escuro (30%) ate a cor cheia,
                // assim o branco do desenho vira a cor cheia e os tracos escuros continuam aparecendo
                float base = 0.30f;
                float span = 0.70f;
                float lr = 0.299f * span;
                float lg = 0.587f * span;
                float lb = 0.114f * span;
                mm = new float[]{
                    tr * lr, tr * lg, tr * lb, 0, tr * base * 255f,
                    tg * lr, tg * lg, tg * lb, 0, tg * base * 255f,
                    tb * lr, tb * lg, tb * lb, 0, tb * base * 255f,
                    0, 0, 0, 1, 0};
            }
            tintPaint.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(mm)));
            src.set(0, 0, bw, bw);
            dst.set(cx - s / 2f, cy - s / 2f, cx + s / 2f, cy + s / 2f);
            c.drawBitmap(gBmp, src, dst, tintPaint);
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            gBmp = null;
            gKey = null;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float s = Math.min(w, h);
            float cx = w / 2f;
            float cy = h / 2f;
            float th = Math.min(s * 0.45f, Math.max(3 * d, s * m.thick / 100f));
            double rad = Math.toRadians(m.rot);
            float k = 1f / (float) (Math.abs(Math.cos(rad)) + Math.abs(Math.sin(rad)));

            c.save();
            c.rotate(m.rot, cx, cy);
            switch (m.type) {
                case T_SETA: {
                    float pad = s * 0.06f;
                    float headLen = Math.min(s * 0.40f, Math.max(th * 2.2f, s * 0.26f));
                    float headHalf = Math.max(th * 1.2f, headLen * 0.72f);
                    float xe = w - pad;
                    float xh = xe - headLen;
                    float ht = th / 2f;
                    path.reset();
                    path.moveTo(pad, cy - ht);
                    path.lineTo(xh, cy - ht);
                    path.lineTo(xh, cy - headHalf);
                    path.lineTo(xe, cy);
                    path.lineTo(xh, cy + headHalf);
                    path.lineTo(xh, cy + ht);
                    path.lineTo(pad, cy + ht);
                    path.close();
                    halo.setStrokeWidth(3 * d);
                    c.drawPath(path, halo);
                    fill.setColor(m.color);
                    c.drawPath(path, fill);
                    break;
                }
                case T_CIRCULO: {
                    float r = Math.max(2 * d, s / 2f - 3 * d - th / 2f);
                    if (m.bg != 0) {
                        fill.setColor(m.bg);
                        c.drawCircle(cx, cy, r, fill);
                    }
                    halo.setStrokeWidth(th + 3 * d);
                    c.drawCircle(cx, cy, r, halo);
                    line.setStrokeWidth(th);
                    line.setColor(m.color);
                    c.drawCircle(cx, cy, r, line);
                    break;
                }
                case T_QUADRADO: {
                    c.scale(k, k, cx, cy);
                    float pad = 3 * d + th / 2f;
                    rect.set(pad, pad, w - pad, h - pad);
                    float rr = s * 0.10f;
                    if (m.bg != 0) {
                        fill.setColor(m.bg);
                        c.drawRoundRect(rect, rr, rr, fill);
                    }
                    halo.setStrokeWidth(th + 3 * d);
                    c.drawRoundRect(rect, rr, rr, halo);
                    line.setStrokeWidth(th);
                    line.setColor(m.color);
                    c.drawRoundRect(rect, rr, rr, line);
                    break;
                }
                default: {
                    float ke = Math.max(k, 0.85f);
                    c.scale(ke, ke, cx, cy);
                    boolean comFundo = m.bg != 0;
                    if (comFundo) {
                        fill.setColor(m.bg);
                        c.drawCircle(cx, cy, s / 2f - 2 * d, fill);
                    }
                    String t = m.text == null ? "" : m.text;
                    float ts = s * (comFundo ? 0.56f : 0.74f);
                    txt.setTextSize(ts);
                    txt.setColor(m.color);
                    float wdt = txt.measureText(t);
                    float maxW = s * (comFundo ? 0.74f : 0.92f);
                    if (wdt > maxW && wdt > 0) {
                        ts = ts * maxW / wdt;
                        txt.setTextSize(ts);
                    }
                    if (m.tint == 0) {
                        Paint.FontMetrics fm = txt.getFontMetrics();
                        c.drawText(t, cx, cy - (fm.ascent + fm.descent) / 2f, txt);
                    } else {
                        drawTinted(c, t, ts, cx, cy, s);
                    }
                    break;
                }
            }
            c.restore();

            if (sel) {
                rect.set(2 * d, 2 * d, w - 2 * d, h - 2 * d);
                dash.setColor(0xFF000000);
                dash.setPathEffect(dashA);
                c.drawRoundRect(rect, 8 * d, 8 * d, dash);
                dash.setColor(0xFFFFFFFF);
                dash.setPathEffect(dashB);
                c.drawRoundRect(rect, 8 * d, 8 * d, dash);
            }
        }
    }
}
