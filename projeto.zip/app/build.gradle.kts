plugins {
    id("com.android.application")
}

android {
    namespace = "com.treinadores.flutuantes"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.treinadores.flutuantes"
        minSdk = 29
        targetSdk = 34
        versionCode = 100000 + (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.1-notificacoes"
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        encoding = "UTF-8"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.8.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
