plugins {
    id("com.android.application")
}

android {
    namespace = "com.treinadores.flutuantes"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.treinadores.flutuantes"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        encoding = "UTF-8"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.8.0")
}
